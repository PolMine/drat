gles 0.2.2
==========

* Datasets for federal elections 2017 and 2021 added


gles 0.2.0
==========

* Added pre- and post-election study for the 2017 federal election to the package.
* Moved dependency knitr from Depends: to Suggests::
