# REUTERS corpus

#### About

This is the REUTERS corpus included in the polmineR-package as a demo corpus. The original data is included in the tm package. See the documentation of the encode-method to learn how the CWB-indexed version of the corpus has been generated.
