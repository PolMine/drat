# GERMAPARLMINI corpus

## About

This is an excerpt from the GERMAPARL corpus.
