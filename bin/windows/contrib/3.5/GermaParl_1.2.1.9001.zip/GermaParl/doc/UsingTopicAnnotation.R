## ---- eval = FALSE-------------------------------------------------------
#  library(polmineR)
#  use("GermaParl")
#  
#  library(topicmodels)
#  library(magrittr)

## ----load_model, eval = FALSE--------------------------------------------
#  k <- 250 # the optimal number of topics
#  model <- readRDS(sprintf("~/Lab/tmp/LDA/lda_%d.RData", k)) # object.size is ~ 1 GB
#  ts <- terms(model, 100)

## ---- eval = FALSE-------------------------------------------------------
#  if (interactive()){
#    for (i in 1:250){
#      print(ts[,i])
#      if (readline("q to quit or any other key to continue") == "q") break
#    }
#  }

## ----check, eval = FALSE-------------------------------------------------
#  topic <- "133"
#  topicRegex <- sprintf("^\\|%s\\|.*$", topic)
#  P <- partition("GERMAPARL", topics = topicRegex, regex = TRUE)
#  PB <- as.speeches(P)
#  for (i in 1:length(PB)) {
#    read(PB[[i]]) %>% highlight(list(yellow = ts[,133])) %>% print()
#    if (readline() == "q") stop()
#  }

## ----check2, eval = FALSE------------------------------------------------
#  topicRegex <- "^(\\|213\\|9\\||\\|9\\|213\\|).*$"
#  P <- partition("GERMAPARL", topics = topicRegex, regex = TRUE)
#  PB <- as.speeches(P)
#  for (i in 1:length(PB)) {
#    read(PB[[i]]) %>% highlight(list(yellow = ts[,213], lightgreen = ts[,9])) %>% print()
#    if (readline() == "q") stop()
#  }

