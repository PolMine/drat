#' Get and Evaluate Pages With Hits for Query From FAZ
#' 
#' To download hitpages from the FAZ archive, you need to be logged in via VPN.
#' 
#' @param query a query string
#' @param outdir directory where to save files
#' @param from starting date, German format (e.g. "01.01.2015", the default)
#' @param to end date, German format (e.g. "29.04.2018", the default)
#' @param hits_displayed number of hits displayed at a single time
#' @export faz_get_hitpages
#' @importFrom utils URLencode txtProgressBar setTxtProgressBar
#' @importFrom pbapply pblapply
#' @importFrom xml2 xml_find_all xml_text
#' @importFrom stringr str_replace_all
#' @aliases faz
#' @rdname faz
#' @examples 
#' \dontrun{
#' faz_download_dir <- file.path(tempdir(), "faz")
#' if (!file.exists(faz_download_dir)) dir.create(faz_download_dir)
#' faz_get_hitpages(
#'   query = "Migrationshintergrund",
#'   outdir = faz_download_dir,
#'   from = "01.01.2015", to = "03.01.2015"
#' )
#' }
faz_get_hitpages = function(query, outdir, from = "01.01.2015", to = "29.04.2018", hits_displayed = 200L){
  i <- 0
  faz_url_raw <- "https://www.faz-biblionet.de/faz-portal/faz-archiv?q=%s&source=&max=%s&sort=&offset=%s&&_ts=1515078308348&DT_from=%s&DT_to=%s&timeFilterType=0#hitlist"
  faz_url <- sprintf(faz_url_raw, query, hits_displayed, i, from, to)
  hit_page <- xml2::read_html(URLencode(faz_url))
  writeLines(text = as.character(hit_page), con = file.path(outdir, sprintf("faz_%s.html", i)))
  
  total_n_articles <- as.character(xml_find_all(hit_page, "//div[@class='hit-count']/span/text()")[1])
  total_n_articles <- as.integer(gsub("[^0-9]", "", total_n_articles))
  message("total number of articles: ", total_n_articles)
  
  pg_bar <- txtProgressBar(min = 0, max = total_n_articles, style = 3)
  
  # Iteriert so lange die Seiten, bis 0 Artikel gefunden werden
  while(length(xml_find_all(hit_page, "//div[@class='hit-bottom']/div/ul/li[1]/text()")) > 0){
    i <- i + hits_displayed
    setTxtProgressBar(pg_bar, i)
    faz_url <- sprintf(faz_url_raw, query, hits_displayed, i, from, to)
    hit_page <- xml2::read_html(URLencode(faz_url))
    writeLines(text = as.character(hit_page), con = file.path(outdir, sprintf("faz_%s.html", i)))
  }
  
  setTxtProgressBar(pg_bar, total_n_articles)
  close(pg_bar)
  return(NULL)
}


#' @param x filename of an html page downloaded, or a \code{data.frame} to aggregate
#' @export faz_parse_hitpage
#' @rdname faz
#' @return \code{faz_parse_hitpage} will return a \code{data.frame}
#' @examples 
#' faz_html_folder <- system.file(package = "faz", "extdata", "html")
#' faz_hitpages <- list.files(faz_html_folder, full.names = TRUE)
#' df <- do.call(rbind, pbapply::pblapply(faz_hitpages, faz_parse_hitpage))
#' df[["date"]] <- as.Date(df[["date"]])
faz_parse_hitpage = function(x){
  if (file.info(x)[["isdir"]]){
    message("parsing files in directory: ", x)
    y <- do.call(rbind, pblapply(list.files(x, full.names = TRUE), faz_parse_hitpage))
  } else {
    hit_page <- xml2::read_html(x)
    n_titles <- length(xml_find_all(hit_page, "//div[@class='hitlist ']/div/div/h3/a/text()"))
    if (n_titles == 0) return(NULL)
    y <- data.frame(
      date = as.character(xml_find_all(hit_page,  "//div[@class='hit-bottom']/div/ul/li[1]/text()"))[1+(0:(n_titles - 1))*2],
      abstract = as.character(xml_text(xml_find_all(hit_page,"//div/p[@class='abstract']"))),
      title = as.character(xml_find_all(hit_page, "//div[@class='hitlist ']/div/div/h3/a/text()")),
      words = as.character(xml_find_all(hit_page, "//div[@class='hit-bottom']/div/ul/li[3]/text()")),
      stringsAsFactors = FALSE
    )
    y[["text"]] <- str_replace_all(y[["abstract"]], "[[:punct:]]", " ")
    y[["date"]] <- as.Date(y[["date"]], format = "%d.%m.%Y")
    y[["words"]] <- as.integer(gsub("^(\\d+)\\s.*?$", "\\1", y[["words"]]))
  }
  y
}


#' @param aggregation either NULL, or "week", "month", "quarter", or "year"
#' @importFrom reshape2 dcast
#' @importFrom xts xts
#' @importFrom zoo as.yearmon as.yearqtr
#' @importFrom lubridate ymd week year week<-
#' @importFrom stats aggregate
#' @importFrom zoo index
#' @return \code{faz_as_xts} will return an \code{xts} object
#' @examples 
#' library(xts)
#' plot(faz_as_xts(df), aggregation = NULL)
#' plot(faz_as_xts(df, aggregation = "week"))
#' plot(faz_as_xts(df, aggregation = "month"))
#' @export faz_as_xts
#' @rdname faz
faz_as_xts = function(x, aggregation = NULL){
  aggr <- table(x[["date"]])
  y <- xts(x = unname(aggr), order.by = as.Date(names(aggr)))
  if (!is.null(aggregation)){
    y <- switch(
      aggregation,
      week = aggregate(y, {a <- ymd(paste(year(index(y)), 1, 1, sep = "-")); week(a) <- week(index(y)); a}),
      month = aggregate(y, as.Date(as.yearmon(index(y)))),
      quarter = aggregate(y, as.Date(as.yearqtr(index(y)))),
      year = aggregate(y, as.Date(paste(gsub("^(\\d{4}).*?$", "\\1", index(y)), "-01-01", sep="")))
    )
  }
  xts(y)
}