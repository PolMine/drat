## ------------------------------------------------------------------------
library(faz)

## ----download, eval = FALSE----------------------------------------------
#  faz_download_dir <- file.path(tempdir(), "faz")
#  if (!file.exists(faz_download_dir)) dir.create(faz_download_dir)
#   faz_get_hitpages(
#     query = "Migrationshintergrund",
#     outdir = faz_download_dir,
#     from = "01.01.2015", to = "03.01.2015"
#  )

## ----parsing, eval = TRUE------------------------------------------------
faz_html_folder <- system.file(package = "faz", "extdata", "html")
faz_hitpages <- list.files(faz_html_folder, full.names = TRUE)
df <- do.call(rbind, pbapply::pblapply(faz_hitpages, faz_parse_hitpage))
df[["date"]] <- as.Date(df[["date"]])

## ------------------------------------------------------------------------
library(xts)
plot(faz_as_xts(df), aggregation = NULL)
plot(faz_as_xts(df, aggregation = "week"))
plot(faz_as_xts(df, aggregation = "month"))

