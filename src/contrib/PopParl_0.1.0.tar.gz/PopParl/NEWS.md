# PopParl 0.1.0 (2019-03-14)

* general
	- fixed small mistakes, missing speakers, etc.

* coverage
	- extended coverage for all corpora until the end of 2018
	- extended coverage for NW (own OCR) for legislative period 13
	- extended coverage for HE based on doc files

* s_attributes
	- enhanced governmental and presidency speakers for party affiliation
	- harmonized speaker format (full name, no title)

* p_attributes
	- added named entity recognition as positional attribute

* format
	- encoding changed from UTF-8 to latin1  



# 2018-10-01

Initial version. 