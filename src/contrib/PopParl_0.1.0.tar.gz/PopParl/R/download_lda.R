#' Download and load supplementary data from web directory.
#' 
#' \code{popparl_download_lda_model} will download a lda topic model
#' from a directory (web dir) and store it in the PopParl package.
#' @param model Name of the model.
#' @param rds_file Name of the data file.
#' @param webdir (web) directory where the data file resides
#' @export popparl_download_lda_model
#' @rdname supplementary_data

popparl_download_lda_model <- function(model = NULL,
                                     webdir = "https://polmine.sowi.uni-due.de/corpora/cwb/fedparl/supplementary_data/topicmodels",
                                     user = NULL,
                                     password = NULL) {

  rds_file <- model
  
  if (is.null(user)) {
    user <- readline(prompt = "Please enter your user name: ")
  }
  if (is.null(password)) {
    password <- readline(prompt = "Please enter password: ")
  }
  
  if (length(model) == 1) {
    tarball <- file.path(webdir, rds_file)
    message("... downloading supplementary data: ", basename(tarball))
    prefix <- gsub("^(https://|http://).*?$", 
                   "\\1", tarball)
    tarball <- gsub("^(https://|http://)(.*?)$", 
                    "\\2", tarball)
    download.file(url = sprintf("%s%s:%s@%s", 
                                prefix, user, password, tarball), destfile = paste0(file.path(system.file(package = "PopParl", "extdata", "topicmodels")), "/", 
                                                                                    rds_file))
  } else {
    for (x in model) popparl_download_lda_model(model = x, rds_file = x, webdir = webdir, user = user, password = password)
  }
}