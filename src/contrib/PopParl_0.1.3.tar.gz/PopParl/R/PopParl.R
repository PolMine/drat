
#' PopParl Corpora.
#' 
#' @keywords package
#' @docType package
#' @rdname popparl
#' @name popparl
#' @aliases PopParl
NULL

