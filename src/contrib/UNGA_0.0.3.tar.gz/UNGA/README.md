# The Protocols of the UN General Assembly: An R Data Package

The package includes a small sample corpus. The large, indexed corpus can be loaded from Amazon S3.
