# v0.0.3
  * sample corpus created, as described in UNGA_sample_corpus.R
  * files configure and configure.win added
  * file tools/setpaths.R added
  * function unga_download_corpus added

# v0.0.2
  * selected meeting records which could be used as an actual data package (Session 49 onwards)
  * replaced 'Beschreibung_UNGAWorkflow.Rmd' with a nearly working Rmd

# v0.0.1
  * moved 'Beschreibung_UNGAWorkflow.Rmd' into data-raw
  * moved folders pdf/txt/xml into data-raw
  * add .Rbuildignore to ignore folder 'data-raw'

