#' United Nations General Assembly Corpus
#' 
#' @keywords package
#' @docType package
#' @rdname unga
#' @name unga
NULL

