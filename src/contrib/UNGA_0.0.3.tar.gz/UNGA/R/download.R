#' Download UNGA corpus from Web Directory.
#' 
#' \code{unga_download_corpus} will get a tarball with the indexed corpus
#' from a directory (web dir) and install the corpus into the UNGA package.
#' @param tarball Name of the tarball.
#' @param webdir (web) directory where the tarball resides
#' @export unga_download_corpus
#' @rdname install_unga
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists
unga_download_corpus <- function(tarball = "unga.tar.gz", webdir = "https://s3.eu-central-1.amazonaws.com/polmine/corpora/cwb/unga"){
  tarball <- file.path(webdir, tarball)
  message("... downloading tarball: ", tarball)
  corpus_install(pkg = "UNGA", tarball = tarball)
}
