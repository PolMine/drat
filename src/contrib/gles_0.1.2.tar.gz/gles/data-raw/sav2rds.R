library(haven)

setwd("~/Lab/gitlab/gles/data-raw")

btw2017 <- read_sav(file = "ZA6802_de_v3-0-1.sav")
save(
  btw2017,
  file = "~/Lab/gitlab/gles/data/btw2017.RData",
  compress = "xz"
)


btw2021 <- read_sav(file = "ZA7702_v1-0-0.sav")
save(
  btw2021,
  file = "~/Lab/gitlab/gles/data/btw2021.RData",
  compress = "xz"
)
