#' Get questionnaire for a data set.
#' 
#' The pdfs with the questionnaires are included in 
#' the data package. When calling the questionnaire function,
#' the pdf document is shown in the browser.
#' 
#' @param glesStudy the study to learn about
#' @export questionnaire
#' @importFrom utils browseURL
questionnaire <- function(glesStudy = c("bt2009", "bt2013", "nrw2010", "nrw2012", "btw2017vw", "btw2017nw", "btw2021vw", "btw2021nw")){
  
  match.arg(
    glesStudy,
    choices = c("bt2009", "bt2013", "nrw2010", "nrw2012", "btw2017vw", "btw2017nw", "btw2021vw", "btw2021nw")
  )
  
  questionnaireFiles <- c(
    bt2009 = "ZA5302_fb_v6-0-0.pdf",
    bt2013 = "ZA5702_fb_v2-0-0.pdf",
    nrw2010 = "ZA5324_fb_v2-0-0.pdf",
    nrw2012 = "ZA5333_fb_v1-0-0.pdf",
    btw2017vw = "ZA6800_fb.pdf",
    btw2017nw = "ZA6801_fb.pdf",
    btw2021vw = "ZA7700_fb.pdf",
    btw2021nw = "ZA7701_fb.pdf"
  )
  
  if (glesStudy %in% names(questionnaireFiles)){
    pdfFile <- system.file("extdata", questionnaireFiles[glesStudy], package = "gles")
    browseURL(pdfFile)
  } else {
    warning("The study requested is not available!")
  }
}

