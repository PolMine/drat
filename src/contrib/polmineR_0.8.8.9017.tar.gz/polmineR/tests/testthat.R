library(testthat)
library(polmineR)
use("polmineR")

test_check("polmineR")
