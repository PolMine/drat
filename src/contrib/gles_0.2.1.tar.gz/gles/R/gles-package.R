#' GLES data package.
#' 
#' A data package with selected GLES studies. The original SPSS files
#' (*.sav) have been transferred to data.frame objects. See vignette 
#' for details.
#' 
#' @author Andreas Blaette (andreas.blaette@@uni-due.de)
#' @keywords package
#' @docType package
#' @rdname gles-package
#' @name gles
#' @importFrom foreign read.spss
#' @examples
#' data(bt2009)
#' data(bt2013)
#' data(nrw2010)
#' data(nrw2012)
#' \dontrun{
#' questionnaire("bt2009")
#' questionnaire("bt2013")
#' questionnaire("nrw2010")
#' questionnaire("nrw2012")
#' }
NULL


#' GLES data for 2009 Federal Election
#' @aliases bt2009
#' @format A \code{data.frame} with ... rows and ... columns.
"bt2009"

#' GLES data for 2012 NRW Election
#' @aliases nrw2012
#' @format A \code{data.frame} with ... rows and ... columns.
"nrw2012"

#' GLES data for 2013 NRW Election
#' @aliases nrw2010
#' @format A \code{data.frame} with ... rows and ... columns.
"nrw2010"

#' GLES data for 2013 Federal Election
#' @aliases bt2013
#' @format A \code{data.frame} with ... rows and ... columns.
"bt2013"

#' GLES data for 2017 Federal Election I
#' @aliases bt2017nw
#' @format A \code{data.frame} with ... rows and ... columns.
"bt2017nw"

#' GLES data for 2017 Federal Election II
#' @aliases bt2017vw
#' @format A \code{data.frame} with ... rows and ... columns.
"bt2017vw"
