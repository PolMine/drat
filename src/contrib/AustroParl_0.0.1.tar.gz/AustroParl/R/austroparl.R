#' Download AustroParl from Web Directory.
#' 
#' \code{austroparl_download_corpus} will get a tarball with the indexed corpus
#' from a designated web space or a local directory and install the corpus into
#' the AustroParl package.
#' @param tarball Name of the tarball.
#' @param dir directory where the tarball resides, either the URL of a webspace,
#'   or a local directory
#' @export austroparl_download_corpus
#' @rdname austroparl
#' @name austroparl
#' @aliases austroparl_download_corpus austroparl AustroParl
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists
austroparl_download_corpus <- function(tarball = "austroparl.tar.gz", dir = "https://s3.eu-central-1.amazonaws.com/polmine/corpora/cwb/austroparl"){
  tarball <- file.path(dir, tarball)
  message("... downloading tarball: ", tarball)
  corpus_install(pkg = "AustroParl", tarball = tarball)
}
