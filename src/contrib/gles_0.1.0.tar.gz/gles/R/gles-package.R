#' GLES data package.
#' 
#' A data package with selected GLES studies. The original SPSS files
#' (*.sav) have been transferred to data.frame objects. See vignette 
#' for details.
#' 
#' @author Andreas Blaette (andreas.blaette@@uni-due.de)
#' @keywords package
#' @docType package
#' @rdname gles-package
#' @name gles
#' @importFrom foreign read.spss
#' @import knitr
#' @examples
#' data(bt2009)
#' data(bt2013)
#' data(nrw2010)
#' data(nrw2012)
#' \dontrun{
#' questionnaire("bt2009")
#' questionnaire("bt2013")
#' questionnaire("nrw2010")
#' questionnaire("nrw2012")
#' }
NULL


#' GLES datasets
#' 
#' Selected data.
#' @rdname datasets
#' @aliases bt2009 bt2013 nrw2010 nrw2012
"bt2009"

#' @rdname datasets
"nrw2012"

#' @rdname datasets
"nrw2010"

#' @rdname datasets
"bt2013"