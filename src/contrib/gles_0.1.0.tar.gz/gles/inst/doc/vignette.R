## ----directories, eval = FALSE-------------------------------------------
#  dirSPSSFiles <- "/Users/blaette/Lab/data/gles"
#  dirRDataFiles <- "/Users/blaette/Lab/repos/gles/data"

## ----files, eval = FALSE-------------------------------------------------
#  savFiles <- c(
#     # "bt2009" = "ZA5302_v6-0-0.sav",
#     "bt2013" = "ZA5702_v2-0-0.sav",
#     "nrw2010" = "ZA5324_v2-0-0.sav",
#     "nrw2012" = "ZA5333_v1-0-0.sav"
#  )

## ----dependencies, eval = FALSE------------------------------------------
#  library(foreign)

## ----as.data.frame, eval = FALSE-----------------------------------------
#  for (dataset in names(savFiles)){
#    print(dataset)
#    fileToGet <- file.path(dirSPSSFiles, savFiles[dataset])
#    df <- read.spss(fileToGet, to.data.frame = TRUE)
#    assign(dataset, df)
#    targetfile = file.path(dirRDataFiles, paste(dataset, ".RData", sep = ""))
#    save(list = dataset, file = targetfile)
#  }

## ----data, eval = FALSE--------------------------------------------------
#  library(gles)
#  data(nrw2012)
#  data(bt2013)
#  data(nrw2010)
#  data(bt2009)

## ----questionnaire, eval = FALSE-----------------------------------------
#  questionnaire("nrw2012")

