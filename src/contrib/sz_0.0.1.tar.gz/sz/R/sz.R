#' Parse SZ Hitpages
#' 
#' @importFrom xml2 read_html xml_find_all xml_text
#' @importFrom stringi stri_match_all_regex
#' @importFrom pbapply pblapply
#' @examples 
#' sz_demo_dir <- system.file(package = "sz", "extdata", "html")
#' df <- do.call(rbind, lapply(list.files(sz_demo_dir, full.names = TRUE), sz_parse_hitpage))
#' @rdname sz
#' @export sz_parse_hitpage
sz_parse_hitpage <- function(x){
  if (file.info(x)[["isdir"]]){
    message("parsing files in directory: ", x)
    y <- do.call(rbind, pblapply(list.files(x, full.names = TRUE), sz_parse_hitpage))
  } else {
    hitpage <- xml2::read_html(x)
    nodes <- xml_find_all(hitpage, xpath = "//div[@class = 'hitInfo']")
    baseinfo <- stri_match_all_regex(
      xml_text(nodes),
      "^\\n\\t\\t\\t\\t(S\uFCddeutsche|SZ)(.*?),\\s*(.*?),\\s*Ressort:\\s(.*?),\\s*W\uF6rter:\\s*(\\d+).*?$"
    )
    df <- as.data.frame(do.call(rbind, baseinfo))
    y <- data.frame(
      edition = sprintf("%s%s", df[[2]], df[[3]]),
      date = as.Date(df[[4]], format = "%d.%m.%Y"),
      rubrik = df[[5]],
      words = as.integer(df[[6]])
    )
    y[["title"]] <- gsub(
      "^\\n\\t+(.*?)$", "\\1",
      xml_text(xml_find_all(hitpage, xpath = "//div[@class = 'hitTitle hitTitleList ']"))
    )
    y[["subtitle"]] <- xml_text(xml_find_all(hitpage, xpath =  "//div[@class = 'hitCaption hitTextList']"))
    y[["text"]] <- xml_text(xml_find_all(hitpage, xpath =  "//div[@class = 'hitText hitTextList']"))
  }
  y
}


#' @param x a \code{data.frame} to aggregate
#' @param aggregation either NULL, or "week", "month", "quarter", or "year"
#' @importFrom reshape2 dcast
#' @importFrom xts xts
#' @importFrom zoo as.yearmon as.yearqtr
#' @importFrom lubridate ymd week year week<-
#' @importFrom stats aggregate
#' @importFrom zoo index
#' @return \code{sz_as_xts} will return an \code{xts} object
#' @examples 
#' library(xts)
#' plot(sz_as_xts(df), aggregation = NULL)
#' plot(sz_as_xts(df, aggregation = "week"))
#' plot(sz_as_xts(df, aggregation = "month"))
#' @export sz_as_xts
#' @rdname sz
sz_as_xts = function(x, aggregation = NULL){
  aggr <- table(x[["date"]])
  y <- xts(x = unname(aggr), order.by = as.Date(names(aggr)))
  if (!is.null(aggregation)){
    y <- switch(
      aggregation,
      week = aggregate(y, {a <- ymd(paste(year(index(y)), 1, 1, sep = "-")); week(a) <- week(index(y)); a}),
      month = aggregate(y, as.Date(as.yearmon(index(y)))),
      quarter = aggregate(y, as.Date(as.yearqtr(index(y)))),
      year = aggregate(y, as.Date(paste(gsub("^(\\d{4}).*?$", "\\1", index(y)), "-01-01", sep="")))
    )
  }
  xts(y)
}
