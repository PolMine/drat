## ------------------------------------------------------------------------
library(sz)

## ----parsing, eval = TRUE------------------------------------------------
sz_html_folder <- system.file(package = "sz", "extdata", "html")
sz_hitpages <- list.files(sz_html_folder, full.names = TRUE)
df <- do.call(rbind, pbapply::pblapply(sz_hitpages, sz_parse_hitpage))
df[["date"]] <- as.Date(df[["date"]])

## ------------------------------------------------------------------------
library(xts)
plot(sz_as_xts(df), aggregation = NULL)
plot(sz_as_xts(df, aggregation = "week"))
plot(sz_as_xts(df, aggregation = "month"))

