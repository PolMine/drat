#' Download GermaParl from Web Directory.
#' 
#' \code{germaparl_download_corpus} will get a tarball with the indexed corpus
#' from a designated web space and install the corpus into the GermaParl package.
#' @param tarball Name of the tarball.
#' @param webdir web directory where the tarball resides
#' @export germaparl_download_corpus
#' @rdname installation
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists
germaparl_download_corpus <- function(tarball = "germaparl.tar.gz", webdir = "https://s3.eu-central-1.amazonaws.com/polmine/corpora/cwb/germaparl"){
  tarball <- file.path(webdir, tarball)
  message("... downloading tarball: ", tarball)
  corpus_install(pkg = "GermaParl", tarball = tarball)
}

#' Download Topicmodels for GermaParl.
#' 
#' @param k The number of topics of the topicmodel.
#' @param webdir The web location.
#' @export germaparl_download_lda
germaparl_download_lda <- function(k = c(100, 150, 200, 250), webdir = "https://s3.eu-central-1.amazonaws.com/polmine/corpora/cwb/germaparl"){
  rdata_file <- sprintf("lda_germaparl_speeches_%d.RData", k)
  tarball <- file.path(webdir, rdata_file)
  if (!url.exists(tarball)){
    stop(sprintf("file '%s' is not available"), rdata_file)
    return(FALSE)
  } else {
    message("... downloading tarball: ", tarball)
    download.file(
      url = tarball,
      destfile = file.path(system.file(package = "GermaParl", "extdata", "topicmodels"), rdata_file)
    )
    return(invisible(TRUE))
  } 
}
