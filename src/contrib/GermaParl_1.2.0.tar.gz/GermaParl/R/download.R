#' Download GermaParl from Web Directory.
#' 
#' \code{germaparl_download_corpus} will get a tarball with the indexed corpus
#' from a designated web space and install the corpus into the GermaParl package.
#' @param tarball Name of the tarball.
#' @param webdir web directory where the tarball resides
#' @export germaparl_download_corpus
#' @rdname installation
#' @importFrom cwbtools corpus_install
germaparl_download_corpus <- function(tarball = "germaparl.tar.gz", webdir = "https://s3.eu-central-1.amazonaws.com/polmine/corpora/cwb/germaparl"){
  tarball <- file.path(webdir, tarball)
  message("... downloading tarball: ", tarball)
  corpus_install(pkg = "GermaParl", tarball = tarball)
}
