#' GermaParl Corpus Class.
#' 
#' The class inherits from the \code{Corpus} class defined in the 
#' package 'polmineR'. So far, it only adds a method 'summary'.
#' 
#' @importFrom R6 R6Class
#' @importFrom polmineR Corpus
#' @importFrom data.table data.table setcolorder rbindlist
#' 
#' @section Methods:
#' \describe{
#'   \item{\code{summary(sAttribute)}}{Get number of tokens in subcorpora
#'   that are prepared on the basis of the s-attribute provided.}
#' }
#' @examples
#' use("GermaParl")
#' GParl <- GermaParl$new()
#' dt <- GParl$summary("year")
#' barplot(
#'   height = dt[["size"]], names.arg = dt[["year"]],
#'   xlab = "year", ylab = "number of tokens"
#' )
#' @export GermaParl
#' @rdname GermaParl
#' @name GermaParl
GermaParl <- R6Class(
  
  classname = "GermaParl",
  inherit = polmineR::Corpus,
  
  public = list(
    
    initialize = function(corpus = "GERMAPARL", pAttribute = NULL){
      super$initialize(corpus = corpus, pAttribute = pAttribute)
    },
    
    summary = function(sAttribute){
      values <- sAttributes("GERMAPARL", sAttribute)
      dts <- lapply(
        values,
        function(value){
          P <- partition("GERMAPARL", def = as.list(setNames(value, sAttribute)), verbose = FALSE)
          dt <- data.table(size = size(P))
          dt[[sAttribute]] <- value
          setcolorder(dt, neworder = c(sAttribute, "size"))
          dt
        }
      )
      dts
      rbindlist(dts)
    }
  )
)
