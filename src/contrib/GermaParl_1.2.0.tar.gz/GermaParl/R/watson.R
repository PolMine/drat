#' @export misses_watson_explaining
misses_watson_explaining <- function(x, linewidth = 60, clear = TRUE, wait = TRUE) {
  txt <- paste0(GermaParl:::.misses_watson_text[[x]], collapse = " ")
  txt_screen <- gsub("polmIneR", "polmineR", txt)
  if (requireNamespace(package = "WatsonR", quietly = TRUE) && requireNamespace(package = "crayon", quietly = TRUE)) {
    options(warn = -1)
    try(
      capture.output(
        WatsonR::watson.tts.process(
          creds = "~/Lab/tmp/watson.json",
          transcript = txt,
          voice_number = 11
        ),
        file = tempfile()
      ),
      silent = TRUE
      )
    options(warn = 0)
  }
  j <- 0
  for (i in 1L:nchar(txt_screen)){
    char <- substr(txt_screen, start = i, stop = i)
    if (char == " " && j > linewidth){
      j <- 0
      cat("\n")
    } else {
      cat(crayon::bold(crayon::green(char)))
      j <- j + 1
    }
    
    Sys.sleep(0.055)
  }
  if (wait){
    cat(crayon::blue(crayon::italic(" [...]")))
    readline()
  }
  if (clear) cat("\014")
  invisible(NULL)
}

.misses_watson_text <- list(
  
  "The GermaParl corpus" = c(
    "The GermaParl Corpus is a corpus of the German federal parliament prepared in the PolMine Project,",
    "and enhanced in a cooperation with the University of Stuttgart."
  ),
  
  "The CWB as indexing and query engine" = c(
    "The corpus is available as XML in a format compliant with the standards of the Text Encoding Initiative,",
    "and as an indexed, and linguistically annotated version. The indexing and query engine used is the",
    "Corpus Workbench, a classic open source toolset widely used for corpus analysis."
    ),
  
  "The polmineR package" = c(
    "The polmIneR package offers specialized functionality to work efficiently with the GermaParl corpus.",
    "We start this short demo by loading the package."
  ),
  
  "Activating GermaParl" = c(
    "Now, we activate the GermaParl corpus by calling the function 'use'."
  ),
  
  "Basic functionality: count" = c(
    "The polmIneR can do basic things efficiently, such as counting.",
    "But the fun part is, that whenver we formulate queries,",
    "the powerful syntax of the Corpus Query Processor (CQP) can be",
    "used."
  ),
  
  "Basic functionality: dispersion" = c(
    "We can also count the dispersion of matches for a query across metadata, or 'structural attributes'",
    "as it is called in the jargon of the Corpus Workbench."
  ),
  
  "From statistics to plots" = c(
    "R is known to be great for visualizations.",
    "At any time, we can turn statistics into plots seamlessly."
  ),
  
  "Basic functionality: kwic" = c(
    "A 'keyword-in-context'-view (or KWIC in short) can be displayed,",
    "using the kwic-method."
  ),
  
  "Basic functionality: kwic (metadata)" = c(
    "The GermaParl corpus includes all kinds of metadata, which can be used throughout.",
    "Of course, metainformation can be displayed when using the kwic-method."
  ),
  
  "Reading" = c(
    "Being able to return to the fulltext of a subcorpus can be key to implement a",
    "research workflow that warrants validity to the results achieved.",
    "Code is theory. Thus, polmIneR is very flexible to create subcorpora, or partitions, and",
    "to display the fulltext of a partition."
  )
  

)

#' @export hitkey
hitkey <- function(flush = FALSE){
  # cat(crayon::italic("Hit key to continue ..."))
  readline()
  if (flush) cat("\014")
  invisible(NULL)
}