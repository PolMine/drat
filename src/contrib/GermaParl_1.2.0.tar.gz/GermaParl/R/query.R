#' @import qlcMatrix
#' @import Matrix
query <- function(cnt, min_size = 250){
  
  # dtm <- as.DocumentTermMatrix("GERMAPARL", pAttribute = "word", sAttribute = "speech") # 90-100 secs
  # saveRDS(dtm, file = "~/Lab/tmp/dtm.RData")
  
  dtm <- readRDS(file = "~/Lab/tmp/dtm.RData") # ~ 3 secs
  
  
  dtm$i <- as.integer(c(dtm$i, rep(x = nrow(dtm) + 1, times = nrow(cnt))))
  dtm$v <- as.integer(c(dtm$v, cnt[["word"]]))
  dtm$j <- as.integer(c(dtm$j, cnt[["word_id"]]))
  dtm$nrow <- as.integer(as.integer(dtm$nrow + 1L))
  dtm$dimnames[[1]] <- c(dtm$dimnames[[1]], "search_vector")
  
  dtm2 <- if (!is.null(min_size)) dtm[which(row_sums(dtm) >= 250),] else dtm
  dtm3 <- weigh(dtm2, method = "tfidf")
  M <- t(as.sparseMatrix(dtm3))
  
  query <- setNames(as.vector(dtm3["search_vector",]), colnames(dtm3))
  query <- query[order(query, decreasing = TRUE)]

  simMatrix <- cosSparse(X = M[, 1L:(ncol(M) - 1L)], Y = Matrix(as.matrix(M[,ncol(M)])))
  simVector <- setNames(simMatrix[,1], rownames(simMatrix))
  simVectorOrdered <- simVector[order(simVector, decreasing = TRUE)]
  
  for (x in names(simVectorOrdered)[1:10]){
    print(x)
    partition("GERMAPARL", speech = x) %>%
      read() %>% 
      highlight(list(yellow = names(head(query, 250)))) %>%
      show()
    if (readline("'q' to quit, any other key to proceed") == "q") break
  }
  
}
