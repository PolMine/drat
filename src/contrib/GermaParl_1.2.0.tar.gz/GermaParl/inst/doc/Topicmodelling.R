## ----initialization, eval = FALSE----------------------------------------
#  library(ldatuning)

## ----topicmodel_optim, eval = FALSE--------------------------------------
#  dtm <- readRDS(file = "~/Lab/gitlab/GermaParl/data-raw/dtm/dtm.RData")

## ----load_data, eval = FALSE---------------------------------------------
#  ldaFiles <- Sys.glob("~/Lab/tmp/LDA/lda_*.RData")
#  noTopics <- as.integer(gsub("^lda_(\\d+)\\.RData$", "\\1", basename(ldaFiles)))
#  LDAs <- pbapply::pblapply(ldaFiles, readRDS)
#  
#  # needs to be identical with the params used for LDAs
#  control <- list(burnin = 1000, iter = 1000, keep = 50, verbose = TRUE)

## ----optimize, eval = FALSE----------------------------------------------
#  result <- data.frame(topics = noTopics)
#  result[["Griffiths2004"]] <- ldatuning:::Griffiths2004(LDAs, control)
#  result[["CaoJuan2009"]] <- ldatuning:::CaoJuan2009(LDAs)
#  result[["Arun2010"]] <- ldatuning:::Arun2010(LDAs, dtm) # fails
#  result[["Deveaud2014"]] <- ldatuning:::Deveaud2014(LDAs)
#  
#  saveRDS(result, file = "~/Lab/gitlab/GermaParl/data-raw/lda_topic_optimization.RData")

## ----topics_vis, eval = FALSE--------------------------------------------
#  ldatuning::FindTopicsNumber_plot(lda_tuning)

