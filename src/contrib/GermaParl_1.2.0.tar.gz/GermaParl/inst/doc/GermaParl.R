## ----s-attributes, echo = FALSE, message = FALSE-------------------------
sAttrsList <- list(
  c("lp", "legislative period", "13 to 18"),
  c("session", "session/protocol number", "1 to 253"),
  c("src", "source material for data preparation", "txt or pdf"),
  c("url", "URL", "URL of the original document"),
  c("agenda_item", "agenda item", "number of the agenda item"),
  c("agenda_item_type", "type of agenda item", "debate/question_time/government_declaration/..."),
  c("date", "date of the session", "YYYY-MM-TT (e.g. '2013-06-28')"),
  c("year", "year of the session", "1996 to 2016"),
  c("interjection", "whether contribution is interjection", "TRUE/FALSE"),
  c("role", "role of the speaker", "presidency/mp/government/..."),
  c("speaker", "Name", "speaker name"),
  c("parliamentary_group", "Parliamentary group", "partliamentary group the speaker is affiliated with"),
  c("party", "Party", "party of the speaker")
)
tab <- do.call(rbind, sAttrsList)
colnames(tab) <- c("s-attribute", "description", "values")
knitr::kable(tab, format = "markdown")

## ----installing_GermaParl, eval = FALSE----------------------------------
#  library(polmineR)
#  install.corpus("GermaParl") # roughly 1 GB, the download may take a while

## ----check_installation, eval = FALSE------------------------------------
#  library(polmineR)
#  use("GermaParl") # to activate the corpus in the data package
#  corpus() # to see whether the GERMAPARL corpus is listed
#  size("GERMAPARL") # to learn about the size of the corpus

## ----sAttributes, eval = FALSE-------------------------------------------
#  sAttributes("GERMAPARL")
#  pAttributes("GERMAPARL")

## ----sAttributes_year, eval = FALSE--------------------------------------
#  sAttributes("GERMAPARL", "year")
#  sAttributes("GERMAPARL", "parliamentary_group")
#  sAttributes("GERMAPARL", "party")

## ----kwic, eval = FALSE--------------------------------------------------
#  K <- kwic("GERMAPARL", query = "Textanalyse")
#  if (interactive()) K

## ----count, eval = FALSE-------------------------------------------------
#  count("GERMAPARL", query = "Minderheitsregierung")
#  count("GERMAPARL", query = c("Asyl", "Flucht", "Abschiebung"))

## ----dispersion, eval = FALSE--------------------------------------------
#  D <- dispersion("GERMAPARL", query = "Flüchtlinge", sAttribute = "year")

## ----dispersion_barplot, eval = FALSE------------------------------------
#  barplot(D[["count"]], names.arg = D[["year"]], las = 2)

## ----cooc, eval = FALSE--------------------------------------------------
#  C <- cooccurrences("GERMAPARL", query = "Terroranschläge")
#  C@stat[1:5]
#  dotplot(C)

## ----count_partition, eval = FALSE---------------------------------------
#  lp16 <- partition("GERMAPARL", lp = 16)
#  count(lp16, query = c("Asyl", "Flucht", "Abschiebung"))
#  dispersion(lp16, query = "Flüchtlinge", sAttribute = "year")

## ----pipe, eval = FALSE--------------------------------------------------
#  library(magrittr)
#  cooccurrences(lp16, query = "Terrorismus") %>%
#    subset(!word %in% c(tm::stopwords("de"), ",", ".")) %>%
#    subset(count_window >= 5) %>%
#    dotplot()

## ----stat_by_lp, eval = FALSE, echo = FALSE, message = FALSE-------------
#  library(polmineR)
#  use("GermaParl")
#  library(knitr)
#  library(data.table)
#  
#  dts <- lapply(
#    13:17,
#    function(lp){
#      P <- partition("GERMAPARL", lp = lp)
#      dates <- as.Date(sAttributes(P, "date"))
#      dt <- polmineR::count(P, pAttribute = "lemma")
#      unknown <- round(sum(dt[grepl("#unknown#", dt[["lemma"]])][["count"]]) / size(P), digits = 3)
#  
#      data.table(
#        lp = lp,
#        protocols = length(unique(sAttributes(P, "session"))),
#        first = min(dates, na.rm = TRUE),
#        last = min(dates, na.rm = TRUE),
#        size = size(P),
#        unknown = unknown
#        )
#    }
#  )
#  dt <- rbindlist(dts)
#  knitr::kable(dt, format = "markdown")

## ----stat_by_year, eval = FALSE, echo = FALSE, message = FALSE-----------
#  years <- as.integer(sAttributes("GERMAPARL", "year"))
#  dts <- lapply(
#    min(years):max(years),
#    function(year){
#      P <- partition("GERMAPARL", year = as.character(year), verbose = FALSE)
#      P.txt <- partition(P, src = "txt")
#      P.pdf <- partition(P, src = "pdf")
#      dt <- polmineR::count(P, pAttribute = "lemma")
#      unknowns <- round(sum(dt[grepl("#unknown#", dt[["lemma"]])][["count"]]) / size(P), digits = 3)
#      data.table(
#        year = year,
#        protocols = length(unique(sAttributes(P, "session"))),
#        txt = length(sAttributes(P.txt, "session")),
#        pdf = length(sAttributes(P.pdf, "session")),
#        size = size(P),
#        unknown = unknowns
#        )
#    }
#  )
#  dt1 <- rbindlist(dts)
#  dt2 <- rbind(dt1, t(data.table(colSums(dt1))), use.names = FALSE, fill = FALSE)
#  dt2[["year"]] <- as.character(dt2[["year"]])
#  dt2[nrow(dt2), 1] <- "TOTAL"
#  knitr::kable(dt2, format = "markdown")

## ----urls, echo = FALSE, message = FALSE---------------------------------

urls <- list(
  c("1996", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/1996/index.htm"),
  c("1997", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/1997/index.htm"),
  c("1998", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/1998/index.htm"),
  c("1999", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/1999/index.htm"),
  c("2000", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/2000/index.htm"),
  c("2001", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/2001/index.htm"),
  c("2002", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/2002/index.html"),
  c("2003", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/2003/index.html"),
  c("2004", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/2004/index.html"),
  c("2005", "http://webarchiv.bundestag.de/archive/2005/1205/bic/plenarprotokolle/pp/2005/index.html"),
  c("2006", "http://webarchiv.bundestag.de/archive/2008/0912/bic/plenarprotokolle/pp/2006/index.html"),
  c("2007", "http://webarchiv.bundestag.de/archive/2008/0912/bic/plenarprotokolle/pp/2007/index.html"),
  c("2008", "http://webarchiv.bundestag.de/archive/2008/0912/bic/plenarprotokolle/pp/2008/index.html"),
  c("2009", "http://webarchiv.bundestag.de/archive/2008/0912/bic/plenarprotokolle/pp/2009/index.html")
)
tab <- do.call(rbind, urls)
colnames(tab) <- c("year", "URL")
knitr::kable(tab, format = "markdown")

