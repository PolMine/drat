library(GermaParl)
library(WatsonR, quietly = TRUE)
setwd("~/Lab/tmp")
options("demo.ask" = FALSE)
hitkey(flush = TRUE)

misses_watson_explaining("The GermaParl corpus", clear = FALSE)

misses_watson_explaining("The CWB as indexing and query engine")

misses_watson_explaining("The polmineR package", clear = FALSE)
library(polmineR)

misses_watson_explaining("Activating GermaParl", clear = FALSE)
use("GermaParl")

hitkey(flush = TRUE)

misses_watson_explaining("Basic functionality: count", clear = FALSE)
count("GERMAPARLMINI", query = '"[eE]urop.*"', cqp = TRUE)

misses_watson_explaining("Basic functionality: dispersion", clear = FALSE, wait = FALSE)
europe <- dispersion("GERMAPARLMINI", query = '"[eE]urop.*"', sAttribute = "party", progress = FALSE)
show(europe)

misses_watson_explaining("From statistics to plots", clear = FALSE, wait = FALSE)
barplot(europe[["count"]], names.arg = europe[["party"]], las = 2)
hitkey(flush = TRUE)


misses_watson_explaining("Basic functionality: kwic", clear = FALSE)
kwic("GERMAPARLMINI", query = '"[eE]urop.*"')
hitkey(flush = FALSE)

misses_watson_explaining("Basic functionality: kwic (metadata)", clear = FALSE)
kwic("GERMAPARLMINI", query = '"[eE]urop.*"', meta = "date")
hitkey(flush = FALSE)
kwic("GERMAPARLMINI", query = '"[eE]urop.*"', meta = c("speaker", "date"))

hitkey(flush = TRUE)

misses_watson_explaining("Reading", clear = FALSE)
speeches <- as.speeches("GERMAPARLMINI", s_attribute_date = "date", s_attribute_name = "speaker")
read(speeches[["Olaf Scholz_2009-11-11_3"]])


# speeches_count <- count(speeches, pAttribute = "word")
# dtm <- as.DocumentTermMatrix(speeches_count, col = "count")
# lda <- LDA(dtm, k = 50, method = "Gibbs")

