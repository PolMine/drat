#' Corpus of the 'tageszeitung' (taz)
#' 
#' @keywords package
#' @docType package
#' @rdname taz
#' @name taz
NULL

#' @details \code{taz_download_corpus} will get a tarball with the indexed corpus
#' from a directory (web dir) and install the corpus into the 'taz' package.
#' @param tarball Name of the tarball.
#' @param webdir (web) directory where the tarball resides
#' @export taz_download_corpus
#' @rdname taz
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists
taz_download_corpus <- function(tarball = "taz.tar.gz", webdir = "https://s3.eu-central-1.amazonaws.com/polmine/corpora/cwb/taz"){
  tarball <- file.path(webdir, tarball)
  message("... downloading tarball: ", tarball)
  corpus_install(pkg = "taz", tarball = tarball)
}

