#' polmineR.anno-package
#' 
#' @author Andreas Blaette (andreas.blaette@@uni-due.de)
#' @references http://polmine.sowi.uni-due.de
#' @keywords package
#' @docType package
#' @rdname polmineR.anno-package
#' @name polmineR.anno-package
NULL

setClass("annotations", contains = "regions")