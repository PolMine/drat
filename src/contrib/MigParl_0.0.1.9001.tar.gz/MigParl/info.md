# Workflow

## Towards indexed CWB-Corpora

MigParl is essentially a consolidated, thematically subset subcorpus of a collection of plenary protocols of the German regional states. As such, the documentation of indexiation of the entire regional state corpora is at the location of this data, which is currently not available for public. 

## From CWB to subset

### Topic Modelling

On the 16 individual collections of the German regional states a topic modelling was performed.

After that, topics were manually annotated (binary - relevant for migration and integration research or not). 

### Subsetting

 In order to extract only relevant speeches from the initial corpora, we add two structural attributes to the corpus: speech and topic (which contains the 5 most relevant topics per speech). We then get the speeches, which belong to at least one of the previously identified state specific topics. After extracting the tokenstream and the metadata per regional state, the raw data is stored on disk for later reencoding.

### Reencoding

Previously extracted tokenstreams and metadata are encoded again as a new corpus, MigParl.

### Version History of the Package

[0.0.1.9001]
Some provisional functions to update tutorials and to find topics added.

[0.0.1.9000]
Updated tutorial references for Workshop.

[0.0.1]
First Beta for MMD Workshop.  





 