#' Function to provide information about topic keywords characterizing the
#' harmonized_topics s_attributes Returns a data frame with
#'   information about which topics contain a certain term
#' @param vocab keywords one might want to look up. 
#' @export

find_topics = function(vocab, n = 100){
  
  terms <- paste0(system.file(package = "MigParl", "extdata"), "/RData/termsPerTopic_2018-11-27.RData")
  terms <- readRDS(terms)
  y <- apply(
    terms, 2,
    function(column) sum(unlist(lapply(vocab, function(t) which(t == rev(column)))))
  )
  y <- y[order(y, decreasing = TRUE)]
  y <- round(y / (length(vocab) * n), 3)
  df <- data.frame(
    topic = as.integer(gsub("^.*?\\s+(\\d+)$", "\\1", names(y))),
    score = unname(y)
  )
  df <- subset(df, score > 0)
  for (i in 1L:10L){
    df[[paste("word", i, sep = "_")]] <- terms[i, df$topic]
  }
  df
}