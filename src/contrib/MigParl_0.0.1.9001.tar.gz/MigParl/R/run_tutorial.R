#' Function to provide information about installed tutorials
#' and to execute interactive learnr tutorials.
#' @param name Name of a tutorial in the tutorial directory
#' @export

run_tutorial <- function(name = NULL) {
  if (is.null(name) || name %in% list.dirs(system.file("tutorials", package = "MigParl"), full.names = FALSE) == FALSE) {
    message("No valid tutorial name given. Please indicate which tutorial you want to run. Available tutorials are:")
    x <- list.dirs(system.file("tutorials", package = "MigParl"), full.names = FALSE)[list.dirs(system.file("tutorials", package = "MigParl"), full.names = FALSE) != ""]
    return(x)
  } else {
    learnr::run_tutorial(name, package = "MigParl")
  }
}

#' Function to update already installed tutorials
#' @param name Name of a tutorial in the tutorial directory
#' @export

update_tutorial <- function(name,  tutorial_file = sprintf("MigParl_%s.html", name),
           webdir = "http://polmine.sowi.uni-due.de/tutorials/migparl") {
    tutorial_path <- file.path(webdir, tutorial_file)
    message("... downloading: ", tutorial_path)
    download.file(url = tutorial_path,
                  destfile = file.path(system.file(package = "MigParl", "tutorials"), name, tutorial_file))
    return(invisible(TRUE))
}
