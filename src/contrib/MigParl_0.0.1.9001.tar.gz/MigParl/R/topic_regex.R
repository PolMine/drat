#' Function to generate a regex query for the harmonized topics s_attribute
#' 
#' @param topics topics one might want to use in queries.
#' @export


topic_regex <- function(topics, topic_pattern = "^.*\\|X\\|.*$") {
  S2 <- strsplit(topics, "|", fixed = TRUE)[[1]]
  S2 <- S2[S2 != ""]
  topic_regex <- as.character()
  for (topic in S2) topic_regex <- paste0(topic_regex,  gsub("X", topic, topic_pattern), sep = "|")
  topic_regex <- substr(topic_regex, 1, nchar(topic_regex)-1)
  topic_regex <- sprintf("(%s)", topic_regex)
  
  return(topic_regex)
}
