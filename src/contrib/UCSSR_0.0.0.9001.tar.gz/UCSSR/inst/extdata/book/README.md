# CorpusAnalysisForSocialScientists
Draft of an extended tutorial how to use polmineR in social science research
