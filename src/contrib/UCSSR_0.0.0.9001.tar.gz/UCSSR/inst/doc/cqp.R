## ---- message = FALSE, results = "hide", echo = FALSE--------------------
# Dieser Code wird im Foliensatz nicht angezeigt und ist nur erforderlich,
# um gegebenenfalls fehlende Pakete nachzuladen:
# kable und kableExtra werden benötigt, um tabellarische Ausgaben zu generieren.
if (!"knitr" %in% rownames(installed.packages())) install.packages("knitr")
if (!"kableExtra" %in% rownames(installed.packages())) install.packages("kableExtra")

## ----initialize, eval = TRUE, message=FALSE------------------------------
library(polmineR)
use("GermaParl")

## ----get_code, eval = FALSE----------------------------------------------
#  if (!"RCurl" %in% rownames(installed.packages())) install.packages("RCurl")
#  library(RCurl)
#  script <- getURL(
#    "https://raw.githubusercontent.com/PolMine/polmineR.tutorials/master/polmineR_CQP.Rmd",
#    ssl.verifypeer = FALSE
#    )

## ----save_code, eval = FALSE---------------------------------------------
#  filename <- "~/Desktop/polmineR_CQP.Rmd"
#  if (interactive()) writeLines(text = script, con = filename)

## ------------------------------------------------------------------------
count("GERMAPARL", query = '"Diskriminierung"', cqp = TRUE)

## ------------------------------------------------------------------------
count("GERMAPARL", query = c('"Liebe"', '"Liebe" %c'), cqp = TRUE)

## ------------------------------------------------------------------------
y <- count("GERMAPARL", query = '"Multikult.*"', cqp = TRUE, breakdown = TRUE)
head(y, n = 3)

## ------------------------------------------------------------------------
y <- count("GERMAPARL", query = '"[mM]ultikult.*"', cqp = TRUE, breakdown = TRUE)
head(y, n = 3)

## ------------------------------------------------------------------------
y <- count("GERMAPARL", query = '"(Zu|Ein|Aus)wanderung.*"', breakdown = TRUE)
head(y)

## ------------------------------------------------------------------------
y <- count("GERMAPARL", query = '"Asyl(suchende|berechtigte|ant|anti)"', cqp = TRUE, breakdown = TRUE)
head(y)

## ---- echo = FALSE, message = FALSE--------------------------------------
P <- partition("GERMAPARL", speaker = "Angela Merkel", lp = "15")
cpos_left <- P@cpos[1,1]
pAttributes <- c("word", "pos", "lemma")
tokenstream_list <- lapply(
  pAttributes,
  function(x) getTokenStream("GERMAPARL", pAttribute = x, encoding = "latin1", left = cpos_left, right = cpos_left + 9)
)
tokenstream_df <- as.data.frame(tokenstream_list)
colnames(tokenstream_df) <- pAttributes
tokenstream_df[["pos"]] <- gsub("^\\$", "\\\\$", tokenstream_df[["pos"]])
tokenstream_df[["cpos"]] <- 0L:9L
tokenstream_df <- tokenstream_df[, c("cpos", pAttributes)]
K <- knitr::kable(tokenstream_df, format = "html", escape = TRUE)
kableExtra::kable_styling(K, font_size = 18, position = "left")

## ---- eval = TRUE--------------------------------------------------------
use("GermaParl")
Q <- '[pos = "NN"] "mit" "Migrations.*"'
C <- count("GERMAPARL", query = Q, breakdown = TRUE)
head(C[,c("match", "count", "share")])

## ------------------------------------------------------------------------
y <- count("GERMAPARL", query = '"(Bundesm|M)inisterium" [] [pos = "NN"]', cqp = TRUE, breakdown = TRUE)
head(y[,c("match", "count", "share")], n = 3)

## ------------------------------------------------------------------------
y <- count("GERMAPARL", query = '"([Kk]riminell.*|Straftat.*)" []{0,5} "Asyl.*"', cqp = TRUE, breakdown = TRUE)
head(y[,c("match", "count", "share")], n = 3)

## ------------------------------------------------------------------------
K <- kwic("GERMAPARL", query = '"Integration" []{0,5} ".*[Ss]cheiter.*"', cqp = TRUE)

## ------------------------------------------------------------------------
D <- dispersion("GERMAPARL", query = '"[rR]assis.*"', sAttribute = "party")

## ------------------------------------------------------------------------
C <- cooccurrences("GERMAPARL", query = '"([mM]uslim.|[iI]slam*)"', cqp = TRUE)

## ------------------------------------------------------------------------
post2001 <- partition("GERMAPARL", year = 2002:2009, verbose = FALSE)
C <- cooccurrences(post2001, query = '"([mM]uslim.|[iI]slam*)"', cqp = TRUE)

