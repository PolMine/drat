## ----klippy, echo=FALSE, include=TRUE------------------------------------
klippy::klippy()

## ----install_required_packages, eval = TRUE------------------------------
required_packages <- c("zoo", "magrittr", "devtools")
for (pkg in required_packages)
  if (!pkg %in% rownames(installed.packages())) install.packages(pkg)

## ----update_polmineR, eval = TRUE----------------------------------------
if (packageVersion("polmineR") < as.package_version("0.7.9.9005"))
  devtools::install_github("PolMine/polmineR", ref = "dev")

## ----load_libraries, eval = TRUE-----------------------------------------
library(zoo, quietly = TRUE, warn.conflicts = FALSE)
library(devtools)
library(magrittr)
library(data.table)
library(xts)

## ----load_polmineR, eval = TRUE, message = FALSE-------------------------
library(polmineR)
use("GermaParl")

## ----get_senti_ws, eval = TRUE, message = FALSE--------------------------
gist_url <- "https://gist.githubusercontent.com/PolMine/70eeb095328070c18bd00ee087272adf/raw/c2eee2f48b11e6d893c19089b444f25b452d2adb/sentiws.R"
devtools::source_url(gist_url) # danach ist Funktion verfügbar
SentiWS <- get_sentiws()

## ----inspect_senti_ws, eval = TRUE---------------------------------------
head(SentiWS, 10)

## ---- eval = TRUE--------------------------------------------------------
vocab <- c(
  positive = nrow(SentiWS[base == TRUE][weight > 0]),
  negative = nrow(SentiWS[base == TRUE][weight < 0])
  )
vocab

## ------------------------------------------------------------------------
options("polmineR.left" = 10L)
options("polmineR.right" = 10L)

## ---- echo = FALSE-------------------------------------------------------
df <- context("GERMAPARL", query = "Islam", p_attribute = c("word", "pos"), verbose = FALSE) %>%
  partition_bundle(node = FALSE) %>%
  set_names(s_attributes(., s_attribute = "date")) %>%
  weigh(with = SentiWS) %>%
  summary()

## ------------------------------------------------------------------------
df <- df[, c("name", "size", "positive_n", "negative_n")] 
head(df, n = 12)

## ------------------------------------------------------------------------
df[["year"]] <- as.Date(df[["name"]]) %>% format("%Y-01-01")
df_year <- aggregate(df[,c("size", "positive_n", "negative_n")], list(df[["year"]]), sum)
colnames(df_year)[1] <- "year"

## ------------------------------------------------------------------------
df_year$negative_share <- df_year$negative_n / df_year$size
df_year$positive_share <- df_year$positive_n / df_year$size

## ------------------------------------------------------------------------
Z <- zoo(
  x = df_year[, c("positive_share", "negative_share")],
  order.by = as.Date(df_year[,"year"])
)

## ------------------------------------------------------------------------
plot(
  Z, ylab = "polarity", xlab = "year", main = "Word context of 'Islam': Share of positive/negative vocabulary",
  cex = 0.8, cex.main = 0.8
)

## ---- eval = TRUE--------------------------------------------------------
words_positive <- SentiWS[weight > 0][["word"]]
words_negative <- SentiWS[weight < 0][["word"]]

## ---- eval = FALSE, message = FALSE--------------------------------------
#  kwic("GERMAPARL", query = "Islam", positivelist = c(words_positive, words_negative)) %>%
#    highlight(lightgreen = words_positive, orange = words_negative) %>%
#    tooltips(setNames(SentiWS[["word"]], SentiWS[["weight"]]))

## ---- eval = TRUE, echo = FALSE, message = FALSE, render = knit_print----
options("polmineR.pagelength" = 7L)
kwic("GERMAPARL", query = "Islam", positivelist = c(words_positive, words_negative)) %>%
  highlight(lightgreen = words_positive, orange = words_negative) %>%
  tooltips(setNames(SentiWS[["word"]], SentiWS[["weight"]]))

## ---- message = FALSE----------------------------------------------------
p <- partition("GERMAPARL", parliamentary_group = "CDU/CSU", interjection = FALSE)

## ------------------------------------------------------------------------
df <- context(p, query = "Islam", p_attribute = c("word", "pos"), verbose = FALSE) %>%
  partition_bundle(node = FALSE) %>%
  set_names(s_attributes(., s_attribute = "date")) %>%
  weigh(with = SentiWS) %>%
  summary() %>%
  subset(select = c("name", "size", "positive_n", "negative_n"))

## ------------------------------------------------------------------------
time_index <- as.Date(df[["name"]]) # 
df[["name"]] <- NULL # Spalte 'name' nicht mehr benötig, wird gelöscht
tseries <- as.xts(df, order.by = time_index) # Umwandlung in Zeitreihen-Objekt

## ------------------------------------------------------------------------
aggregate_time_series <- function(x, aggregation){
  y <- switch(
    aggregation,
    week = aggregate(x, {a <- lubridate::ymd(paste(lubridate::year(index(x)), 1, 1, sep = "-")); lubridate::week(a) <- lubridate::week(index(x)); a}),
    month = aggregate(x, as.Date(as.yearmon(index(x)))),
    quarter = aggregate(x, as.Date(as.yearqtr(index(x)))),
    year = aggregate(x, as.Date(sprintf("%s-01-01", gsub("^(\\d{4})-.*?$", "\\1", index(x)))))
    )
  y$negative_share <- -1 * (y$negative_n / y$size)
  y$positive_share <- y$positive_n / y$size
  as.xts(y)
}

## ------------------------------------------------------------------------
aggr <- aggregate_time_series(tseries, "year")

## ---- fig.height = 4, fig.width = 4--------------------------------------
plot(
  aggr[,c("positive_share", "negative_share")],
  multi.panel = FALSE,
  ylab = "polarity",
  xlab = "year",
  main = "year",
  cex = 0.5,
  cex.main = 0.5,
  ylim = c(-0.05, 0.05)
  )

## ---- eval = FALSE-------------------------------------------------------
#  par(mfrow = c(2,2))
#  for (aggregation_level in c("week", "month", "quarter", "year")){
#    x <- aggregate_time_series(tseries, aggregation_level)
#    x <- x[,c("positive_share", "negative_share")]
#  
#    y <- plot(
#      x,
#      multi.panel = FALSE,
#      ylab = "polarity",
#      xlab = "year",
#      main = aggregation_level,
#      cex = 0.3,
#      cex.main = 0.3,
#      ylim = c(-0.05, 0.05),
#      type = "l"
#    )
#    show(y)
#  }

## ---- echo = FALSE, fig.height = 4---------------------------------------
par(mfrow = c(2,2))
for (aggregation_level in c("week", "month", "quarter", "year")){
  x <- aggregate_time_series(tseries, aggregation_level)
  x <- x[,c("positive_share", "negative_share")]
  
  y <- plot(
    x,
    multi.panel = FALSE,
    ylab = "polarity",
    xlab = "year",
    main = aggregation_level,
    cex = 0.3,
    cex.main = 0.3,
    ylim = c(-0.05, 0.05),
    type = "l"
  )
  show(y)
}

