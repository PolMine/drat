## ---- include = FALSE----------------------------------------------------
Sys.setenv(CORPUS_REGISTRY = "") # to avoid that all system corpora show up
options("kableExtra.html.bsTable" = TRUE)

## ----include = FALSE-----------------------------------------------------
if (! "icon" %in% rownames(installed.packages()) ) devtools::install_github("ropenscilabs/icon")

## ---- echo = FALSE-------------------------------------------------------
library(kableExtra)

## ----load_libraries, eval = TRUE, message = FALSE------------------------
library(polmineR)
library(data.table)

## ------------------------------------------------------------------------
corpus()

## ------------------------------------------------------------------------
size("REUTERS")

## ---- message = FALSE----------------------------------------------------
use("GermaParl")

## ------------------------------------------------------------------------
corpus()

## ---- eval = FALSE-------------------------------------------------------
#  registry()

## ---- eval = FALSE-------------------------------------------------------
#  Sys.setenv(CORPUS_REGISTRY = "/PFAD/ZU/REGISTRY/VERZEICHNIS")

## ------------------------------------------------------------------------
p_attributes("GERMAPARL")

## ---- echo = FALSE-------------------------------------------------------
df <- data.frame(lapply(
  c("word", "pos", "lemma"),
  function(p_attribute){
    ts <- get_token_stream("GERMAPARL", left = 0, right = 9, p_attribute = p_attribute)
    Encoding(ts) <- registry_get_encoding("GERMAPARL")
    ts
  }
    
))
colnames(df) <- c("word", "pos", "lemma")
df <- data.frame(cpos = 0:9, df)
kableExtra::kable(df) %>% 
  kableExtra::kable_styling(bootstrap_options = "striped", font_size = 20L, position = "center")


## ------------------------------------------------------------------------
s_attributes("GERMAPARL")

## ------------------------------------------------------------------------
s_attributes("GERMAPARL", s_attribute = "year")

## ------------------------------------------------------------------------
size("GERMAPARL")

## ------------------------------------------------------------------------
size("GERMAPARL", s_attribute = "lp")

## ---- eval = TRUE--------------------------------------------------------
s <- size("GERMAPARL", s_attribute = "year")

## ---- eval = FALSE-------------------------------------------------------
#  barplot(
#    height = s$size / 1000,
#    names.arg = s$year,
#    main = "Größe GermaParl nach Jahr",
#    ylab = "Token (in Tausend)", xlab = "Jahr",
#    las = 2
#    )

## ---- echo = FALSE-------------------------------------------------------
barplot(
  height = s$size / 1000, # Höhe der Balken
  names.arg = s$year, # Labels auf der X-Achse
  las = 2, # Drehung der Labels auf der X-Achse um 90 Grad
  main = "Größe GermaParl nach Jahr", # Überschrift der Abbildung
  ylab = "Token (in Tausend)", # Beschriftung Y-Achse
  xlab = "Jahr" # Beschriftung der X-Achse
  )

## ------------------------------------------------------------------------
dt <- size("GERMAPARL", s_attribute = c("speaker", "party"))
df <- as.data.frame(dt) # Umwandlung in data.frame
df_min <- subset(df, speaker != "") # In wenigen Fällen wurde Sprecher nicht erkannt
head(df_min)

## ---- echo = FALSE-------------------------------------------------------
DT::datatable(df_min)

## ------------------------------------------------------------------------
dt <- size("GERMAPARL", s_attribute = c("parliamentary_group", "lp"))
dt_min <- subset(dt, parliamentary_group != "") # Bearbeitung data.table wie data.frame

## ------------------------------------------------------------------------
tab <- dcast(parliamentary_group ~ lp, data = dt_min, value.var = "size")
setnames(tab, old = "parliamentary_group", new = "Fraktion")

## ---- eval = FALSE-------------------------------------------------------
#  DT::datatable(tab)

## ---- echo = FALSE, eval = TRUE------------------------------------------
DT::datatable(tab)

## ------------------------------------------------------------------------
pg <- tab[["Fraktion"]] # Für Beschriftung des barplot "retten" wir die Fraktionen
tab[["Fraktion"]] <- NULL # Spalte "Fraktionen" wird an dieser Stelle beseitigt
m <- as.matrix(tab) # Umwandlung des data.table in Matrix
m[is.na(m)] <- 0 # Wo NA-Werte in der Tabelle sind, ist die Korpusgröße 0

## ------------------------------------------------------------------------
colors <- c(
  "CDU/CSU" = "black", FDP = "yellow",
  SPD = "red", GRUENE = "green", LINKE = "pink", PDS = "pink",
  fraktionslos = "lightgrey", parteilos = "darkgrey"
  )

## ---- eval = FALSE-------------------------------------------------------
#  barplot(
#    m / 1000, # Höhe der Balken - Zahl Worte, in Tausend
#    xlab = "Worte (in Tausend)", # Beschriftung der X-Achse
#    beside = TRUE, # Gruppierung
#    col = colors[pg] # Farben der Balken, Indizierung gewährleistet richtige Reihenfolge
#    )
#  # Um die Legende zweispaltig gestalten zu können, erstellen wir die Legende gesondert.
#  legend(
#    x = "top", # Platzierung Legende oben mittig
#    legend = pg, # Beschriftung mit Benennung Fraktion
#    fill = colors[pg], # Indizierung gewährleistet, dass nichts verrutschen kann
#    ncol = 2, # zweispaltige Legende
#    cex = 0.7 # kleine Schrift
#    )

## ---- echo = FALSE-------------------------------------------------------
barplot(m / 1000, xlab = "Worte (in Tausend)", beside = TRUE, col = colors[pg])
legend(x = "top", legend = pg, fill = colors[pg], ncol = 2, cex = 0.7)

## ------------------------------------------------------------------------
size("GERMAPARL", s_attribute = "speaker")[speaker == "Angela Merkel"]

