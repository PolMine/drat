library(testthat)
library(cwbtools)

test_check("cwbtools")
