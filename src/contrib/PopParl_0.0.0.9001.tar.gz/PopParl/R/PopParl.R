
#' MigTex Corpus.
#' 
#' @keywords package
#' @docType package
#' @rdname migtex
#' @name migtex
#' @aliases MigTex
NULL

