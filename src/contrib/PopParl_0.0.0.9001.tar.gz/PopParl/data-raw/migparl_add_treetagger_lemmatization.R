# Define TREETAGGER_PATH before loading ctk library
Sys.setenv(TREETAGGER_PATH = "/opt/treetagger") 
library(ctk)

add_treetagger_lemmatization <- function(sourceDir = teidir, targetDir = teidir, lang = "de", verbose = TRUE) {
  if (verbose) message("... reading in tokenstream.csv")
  tokenstreamDT <-  data.table::fread(sprintf("%s/tokenstream.csv", sourceDir), showProgress = interactive())
  
  # to make processing robust
  tokenstreamDT <- tokenstreamDT[!is.na(tokenstreamDT[["word"]])] # NAs cause problems!
  tokenstreamDT <- tokenstreamDT[which(tokenstreamDT[["word"]] != "")] # blank words too
  setkeyv(tokenstreamDT, cols = "id") # ndjson2tsv may have mixed up the order
  setorderv(tokenstreamDT, cols = "id")
  
  if (verbose) message("... writing column with tokens to temporary file")
  tmpdir <- tempdir()
  data.table::fwrite(
    tokenstreamDT[, "word", with = TRUE],
    file = file.path(tmpdir, "tokenstream.tok"),
    col.names = FALSE,
    quote = FALSE, showProgress = interactive()
  )
  
  if (verbose) message("... run treetagger")
  ctk::treetagger(sourceDir = tmpdir, targetDir = tmpdir, filename = "tokenstream.tok", param = list(lang = lang, tokenize = FALSE))
  
  if (verbose) message("... read in treetagger output and supplement tokenstream data.table")
  
  treetaggerOutput <- data.table::fread(
    file.path(tmpdir, "tokenstream.vrt"), sep = "\t", col.names = c("word", "pos", "lemma"),
    header = FALSE, showProgress = interactive()
  )
  tokenstreamDT[, lemma := treetaggerOutput[["lemma"]]]
  tokenstreamDT[, lemma := gsub("^<unknown>$", "#unknown#", tokenstreamDT[["lemma"]])]
  
  if (verbose) message("... write result back to tokenstream.csv")
  data.table::fwrite(
    tokenstreamDT, file = sprintf("%s/tokenstream.csv", sourceDir),
    showProgress = interactive()
  )
  
  if (verbose) message("... write result back to tokenstream slot")
  CD$tokenstream <- tokenstreamDT
}