setwd("~/lab/gitlab/cwb_uncompressed")


corpora <- unique(FederalActorsGermany::speakerData$regional_state)

for (corpus in corpora) {
  print(corpus)
  # create name and paths to directories to tar later
  tar_name <- paste0(tolower(corpus), ".tar.gz")
  tar_files_reg <-"registry"
  tar_files_ind <- "indexed_corpora"
  tar_files <- c(tar_files_reg, tar_files_ind)
  
  
  # create system cmds 
  # if the tar is zipped only by name rename .tar.gz to .tar
 mv_cmd <- paste0("mv ", corpus, ".tar.gz ", corpus, ".tar")
 # untar
 untar_cmd <- paste0("tar -xzf ", corpus, ".tar")
 # remove initial .tar
 rm_cmd <- paste0("rm ", corpus, ".tar")
# copy info file in indexed_corpora directory
 cp_cmd <- paste0("cp info.md ", "indexed_corpora/", tolower(corpus), "/")
 # tar again with internal R method and gzip

 # renaming instead of removal of created registry and corpora directories because of right issues
 rename_cmd_1 <- paste0("mv ", tar_files_ind, " ", tar_files_ind, "_", corpus)
 rename_cmd_2 <- paste0("mv ", tar_files_reg, " ", tar_files_reg, "_", corpus)
 
 # perform
 
 system(mv_cmd)
 system(untar_cmd)
 system(rm_cmd)
 system(cp_cmd)
 tar(tar_name, tar_files, compression = "gzip")
 system(rename_cmd_1)
 system(rename_cmd_2)
 
 
}

# remove directories by hand afterwards
