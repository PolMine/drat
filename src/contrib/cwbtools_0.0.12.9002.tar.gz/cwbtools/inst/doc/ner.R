## ---- eval = FALSE-------------------------------------------------------
#  use("RcppCWB")
#  p <- partition("UNGA", date = "2018-03-20", who = "Al Hussein")
#  s <- NLP::String(as.String(p))
#  a <- as.Annotation(p, type = "word")
#  sent <- as.Annotation(p, type = "sentence")
#  a1 <- c(sent, a)
#  
#  words <- s[a1[a1$type == "word"]]
#  sentences <- s[a1[a1$type == "sentence"]]

## ----eval = FALSE--------------------------------------------------------
#  library(openNLP)
#  install.packages("openNLPmodels.de", repos = "http://datacube.wu.ac.at/", type = "source")
#  
#  entity_annotator <- Maxent_Entity_Annotator(language = "en", kind = "person")
#  entity_annotator <- Maxent_Entity_Annotator(language = "en", kind = "date")
#  entity_annotator <- Maxent_Entity_Annotator(language = "en", kind = "location")
#  entity_annotator <- Maxent_Entity_Annotator(language = "en", kind = "organization")
#  ner <- NLP::annotate(s, entity_annotator, a)
#  s[ner[ner$type == "entity"]]
#  
#  entity_annotator <- Maxent_Entity_Annotator(language = "de")
#  ner <- annotate(s, entity_annotator, a1)
#  s[ner]
#  s[entity_annotator(s, a2)]

