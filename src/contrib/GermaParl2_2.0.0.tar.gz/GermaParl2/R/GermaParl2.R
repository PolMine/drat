#' GermaParl R Data Package.
#' 
#' `GermaParl2` is  a corpus of parliamentary debates in the German Bundestag.
#' The corpus has been linguistically annotated and indexed using the data
#' format of the `Corpus Workbench` (CWB). To make full use if this data format,
#' working with `GermaParl2` in combination with the 'polmineR' package is
#' recommended.
#' 
#' The GermaParl2 package initially only includes  a subset of the GermaParl2
#' corpus which serves as a sample corpus ("GERMAPARL2MINI"). To download the
#' full corpus from the open science repository `Zenodo`, use the
#' `germaparl2_download_corpus()` function.
#' 
#' The `GermaParl2` R package and the `GermaParl2` corpus are two
#' different pieces of research data: The package offers a mechanism to ship,
#' easily install and augment the data. The indexed corpus is the actual data.
#' Package and corpus have different version numbers and should be quoted in
#' combination in publications. We recommend to follow the instructions you see
#' when calling `citation(package = "GermaParl")`. To ensure that the
#' recommended citation fits the corpus you use, the citation for the corpus is
#' available only when a version of `GermaParl2` has been downloaded and
#' installed.
#' 
#' @references Blaette, Andreas (2018): "Using Data Packages to Ship Annotated
#'   Corpora of Parliamentary Protocols: The GermaParl R Package". ISBN
#'   979-10-95546-02-3. Available online at
#'   \url{http://lrec-conf.org/workshops/lrec2018/W2/pdf/15_W2.pdf}.
#' @author Andreas Blaette \email{andreas.blaette@@uni-due.de}
#' @keywords package
#' @docType package
#' @aliases GermaParl2 GermaParl2-package
#' @rdname GermaParl2-package
#' @name GermaParl2-package
"_PACKAGE"

