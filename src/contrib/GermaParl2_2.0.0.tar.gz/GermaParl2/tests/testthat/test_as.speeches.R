library(polmineR)

foo <- corpus("GERMAPARL2") %>%
  subset(protocol_year == "2001") %>%
  subset(p) %>%
  as.speeches(s_attribute_date = "protocol_date", s_attribute_name = "speaker_name")
