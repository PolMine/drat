library(polmineR)

x <- corpus("GERMAPARL2") %>%
  subset(grepl("2001-09-.*", protocol_date)) %>%
  subset(p) %>%
  split(s_attribute = "speaker_name")
