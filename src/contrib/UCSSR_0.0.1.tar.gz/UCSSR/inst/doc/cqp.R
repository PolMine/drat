## ---- message = FALSE, results = "hide", echo = FALSE--------------------
# Dieser Code wird im Foliensatz nicht angezeigt und ist nur erforderlich,
# um gegebenenfalls fehlende Pakete nachzuladen:
# kable und kableExtra werden benötigt, um tabellarische Ausgaben zu generieren.
if (!"knitr" %in% rownames(installed.packages())) install.packages("knitr")
if (!"kableExtra" %in% rownames(installed.packages())) install.packages("kableExtra")

## ----initialize, eval = TRUE, message=FALSE------------------------------
library(polmineR)
use("GermaParl")

## ------------------------------------------------------------------------
library(magrittr)

## ------------------------------------------------------------------------
library(data.table)

## ---- collapse = TRUE----------------------------------------------------
count("GERMAPARL", query = '"Diskriminierung"', cqp = TRUE)

## ---- collapse = TRUE----------------------------------------------------
count("GERMAPARL", query = c('"Liebe"', '"Liebe" %c'), cqp = TRUE)

## ---- collapse = TRUE----------------------------------------------------
count("GERMAPARL", '".iebe"', cqp = TRUE) %>% head()
count("GERMAPARL", '"\\d\\d\\d\\d"', cqp = TRUE) %>% head()

## ---- collapse = TRUE----------------------------------------------------
count("GERMAPARL", query = '"Multikult.*"', cqp = TRUE, breakdown = TRUE) %>% head(n = 3)

## ---- collapse = TRUE----------------------------------------------------
count("GERMAPARL", query = '"[Mm]ultikult.*"', cqp = TRUE, breakdown = TRUE) %>% head(n = 3)

## ---- collapse = TRUE----------------------------------------------------
count("GERMAPARL", query = '"(Zu|Ein|Aus)wanderung.*"', breakdown = TRUE) %>% head()

## ---- collapse = TRUE----------------------------------------------------
count("GERMAPARL", query = '"Asyl(suchende|berechtigte|ant|anti)"', cqp = TRUE, breakdown = TRUE) %>% head()

## ---- echo = FALSE, message = FALSE--------------------------------------
P <- partition("GERMAPARL", speaker = "Angela Merkel", lp = "15")
cpos_left <- P@cpos[1,1]
pAttributes <- c("word", "pos", "lemma")
tokenstream_list <- lapply(
  pAttributes,
  function(x) getTokenStream("GERMAPARL", pAttribute = x, encoding = "latin1", left = cpos_left, right = cpos_left + 1000)
)
tokenstream_df <- as.data.frame(tokenstream_list)
colnames(tokenstream_df) <- pAttributes
tokenstream_df[["pos"]] <- gsub("^\\$", "\\\\$", tokenstream_df[["pos"]])
tokenstream_df[["cpos"]] <- 0L:1000L
tokenstream_df <- tokenstream_df[, c("cpos", pAttributes)]
DT::datatable(tokenstream_df)

## ---- eval = TRUE, message = FALSE---------------------------------------
Q <- '[pos = "NN"] "mit" "Migrations.*"'
C <- count("GERMAPARL", query = Q, breakdown = TRUE)
head(C[,c("match", "count", "share")])

## ------------------------------------------------------------------------
count("GERMAPARL", query = '"(Bundesm|M)inisterium" [] [pos = "NN"]', cqp = T, breakdown = T) %>% 
  head(n = 3) %>% subset(select = c("match", "count", "share"))

## ------------------------------------------------------------------------
count("GERMAPARL", query = '"([Kk]riminell.*|Straftat.*)" []{0,5} "Asyl.*"', cqp = TRUE, breakdown = TRUE) %>%
  head(n = 3) %>% subset(select = c("match", "count", "share"))

## ---- message = FALSE----------------------------------------------------
Q <- '("[tT]error.*" []{0,9} "[iI]slam.*" | "[iI]slam.*" []{0,9} "[tT]error.*")'
Y <- count("GERMAPARL", query = Q, cqp = TRUE)
Y[, "count"]

## ---- echo = FALSE-------------------------------------------------------
options("polmineR.pagelength" = 6L)

## ---- render = knit_print------------------------------------------------
kwic("GERMAPARL", query = '"Integration" []{0,5} ".*[Ss]cheiter.*"', cqp = TRUE)

## ---- echo = FALSE-------------------------------------------------------
options("polmineR.pagelength" = 5L)

## ---- render = knit_print, message = FALSE-------------------------------
kwic("GERMAPARL", query = '"[iI]slam.*"', positivelist = "[tT]error.*", regex = T, cqp = T) %>%
  highlight (yellow = "[tT]error.*", regex = TRUE)

## ---- message = FALSE----------------------------------------------------
dispersion("GERMAPARL", query = '"[rR]assis.*"', s_attribute = "party")

## ---- message = FALSE----------------------------------------------------
cooccurrences("GERMAPARL", query = '"([mM]uslim.|[iI]slam*)"', cqp = TRUE) %>%
  as.data.table() %>% subset(rank_ll < 5) %>% DT::datatable() # Einbindung in Folie als htmlwidget

## ---- message = FALSE, eval = FALSE--------------------------------------
#  partition("GERMAPARL", year = 2002:2009) %>%
#    cooccurrences(query = '"([mM]uslim.|[iI]slam*)"', cqp = TRUE)

