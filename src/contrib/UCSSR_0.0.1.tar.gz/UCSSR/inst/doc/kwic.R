## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(widgetframe_self_contained = FALSE)
knitr::opts_chunk$set(widgetframe_isolate_widgets = TRUE)
knitr::opts_chunk$set(widgetframe_widgets_dir = 'widgets' ) 

## ----install_required_packages, eval = TRUE, echo = FALSE, message = FALSE----
required_packages <- c("vembedr", "htmltools", "devtools", "devtools", "widgetframe")
for (pkg in required_packages)
  if (!pkg %in% rownames(installed.packages())) install.packages(pkg)
if (!"annolite" %in% rownames(installed.packages()))
  devtools::install_github("PolMine/annolite")

## ----update_polmineR, eval = TRUE, message = FALSE-----------------------
if (packageVersion("polmineR") < as.package_version("0.7.9.9008"))
  devtools::install_github("PolMine/polmineR", ref = "dev")

## ----initialize, eval = TRUE, message = FALSE----------------------------
library(polmineR)
use("GermaParl")

## ---- echo = FALSE-------------------------------------------------------
options("polmineR.pagelength" = 4L)

## ---- eval = TRUE, message = FALSE, render = knit_print------------------
kwic("GERMAPARL", query = "Migrationshintergrund")

## ---- eval = TRUE, echo = FALSE, message = FALSE-------------------------
vembedr::embed_youtube("F4UkFI0aolI", height = 400, width = 600)

## ---- echo = FALSE, message = FALSE--------------------------------------
options("polmineR.pagelength" = 3L)

## ---- eval = TRUE,  render = knit_print, message = FALSE-----------------
bt2005 <- partition("GERMAPARL", year = 2005)
kwic(bt2005, query = "Migrationshintergrund")

## ---- echo = FALSE, message = FALSE--------------------------------------
options("polmineR.pagelength" = 5L)

## ---- eval = TRUE, render = knit_print, message = FALSE------------------
kwic(bt2005, query = '[pos = "NN"] "mit" "Migrationshintergrund"', cqp = TRUE)

## ---- echo = FALSE, message = FALSE--------------------------------------
options("polmineR.pagelength" = 4L)

## ---- eval = TRUE, render = knit_print, message = FALSE------------------
kwic("GERMAPARL", query = "Ausländer", left = 15, right = 15)

## ------------------------------------------------------------------------
getOption("polmineR.left")
getOption("polmineR.right")

## ------------------------------------------------------------------------
options(polmineR.left = 10)
options(polmineR.right = 10)

## ---- echo = FALSE-------------------------------------------------------
options("polmineR.pagelength" = 5L)
options("polmineR.left" = 5L)
options("polmineR.right" = 5L)

## ---- eval = TRUE, render = knit_print, message = FALSE------------------
kwic(bt2005, query = "Ausländer", s_attributes = "party", verbose = FALSE)

## ---- echo = FALSE, message = FALSE--------------------------------------
options("polmineR.pagelength" = 3L)

## ---- eval = TRUE, render = knit_print, message = FALSE------------------
kwic(bt2005, query = "Ausländer", s_attributes = c("party", "date"), verbose = FALSE)

## ---- message = FALSE, eval = FALSE--------------------------------------
#  s_attributes(bt2005)

## ---- eval = TRUE, render = knit_print, message = FALSE------------------
K <- kwic(
  "GERMAPARL", query = "Islam", s_attributes = c("party", "date"),
  positivelist = "Terror"
)
K <- highlight(K, yellow = "Terror")
K

## ---- eval = FALSE, message = FALSE--------------------------------------
#  K <- kwic(bt2005, query = "Ausländer")
#  read(K, i = 1)

## ----generate_fulltext_output, message = FALSE, echo = FALSE-------------
i <- 1L
metadata <- c("speaker", "date", "party")
K <- kwic(bt2005, query = "Ausländer", s_attributes = metadata)
P <- partition(
  corpus(K),
  def = lapply(setNames(metadata, metadata), function(x) K@table[[x]][i]),
  type = "plpr"
)
data <- annolite::as.fulltextdata(P, headline = "Cornelie Sonntag-Wolgast (2005-01-21)")
data$annotations <- data.frame(
  text = c("", "", ""),
  code = c("yellow", "lightgreen", "yellow"),
  annotation = c("", "", ""),
  id_left = c(
    min(K@cpos[hit_no == i][direction == -1][["cpos"]]),
    min(K@cpos[hit_no == i][direction == 0][["cpos"]]),
    min(K@cpos[hit_no == i][direction == 1][["cpos"]])
    ),
  id_right = c(
    max(K@cpos[hit_no == i][direction == -1][["cpos"]]),
    min(K@cpos[hit_no == i][direction == 0][["cpos"]]),
    max(K@cpos[hit_no == i][direction == 1][["cpos"]])
    )
)
W <- annolite::fulltext(data, dialog = NULL, box = TRUE, width = 1000, height = 400)
Y <- widgetframe::frameWidget(W)
Y

