## ---- eval = TRUE, echo = FALSE------------------------------------------
vembedr::embed_youtube("frpQm2UcZJk")

## ---- eval = FALSE-------------------------------------------------------
#  install.packages("polmineR")

## ---- eval = FALSE-------------------------------------------------------
#  install.packages("devtools")
#  devtools::install_github("PolMine/polmineR", ref = "dev")

## ---- eval = FALSE-------------------------------------------------------
#  install.packages("drat")
#  drat::addRepo("polmine") # 'polmine' muss hier ausnahmsweise klein geschrieben werden!
#  install.packages(pkgs = c("cwbtools", "GermaParl"))

## ---- eval = FALSE-------------------------------------------------------
#  GermaParl::germaparl_download_corpus() # hier kommt mehr als 1 GB, braucht sicher einen Moment!

## ---- eval = FALSE-------------------------------------------------------
#  library(polmineR)

## ---- eval = FALSE-------------------------------------------------------
#  use("GermaParl")
#  c("REUTERS", "GERMAPARLMINI", "GERMAPARL") %in% corpus()[["corpus"]]

## ---- eval = FALSE-------------------------------------------------------
#  size("GERMAPARL")

## ---- eval = FALSE-------------------------------------------------------
#  partition("GERMAPARL", year = "2001") # Anlegen eines Subkorpus ("Partition")
#  kwic("GERMAPARL", query = "Integration") # einfache Ansicht von Konkordanzen
#  kwic("GERMAPARL", '[pos = "NN"] "mit" "Migrationshintergrund"', cqp = TRUE) # Nutzung CQP-Syntax
#  cooccurrences("GERMAPARL", "Islam") # eine erste Kookkurrenz-Berechnung
#  count("GERMAPARL", query = c("Islam", "Muslime", "Koran")) # simples Zählen

## ---- eval = FALSE-------------------------------------------------------
#  merkel <- partition("GERMAPARLMINI", date = "2009-11-10", speaker = "Merkel", regex = TRUE)
#  read(merkel, meta = c("speaker", "date"))

