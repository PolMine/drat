## ---- include = FALSE----------------------------------------------------
options("kableExtra.html.bsTable" = TRUE) # macht schöne Tabellen-Ausgabe verfügbar

## ----include = FALSE-----------------------------------------------------
if (! "icon" %in% rownames(installed.packages()) ) devtools::install_github("ropenscilabs/icon")

## ---- echo = FALSE-------------------------------------------------------
library(kableExtra)

## ---- message = FALSE----------------------------------------------------
library(polmineR)
use("GermaParl")

## ----load_libraries, eval = TRUE, message = FALSE------------------------
library(magrittr)

## ------------------------------------------------------------------------
s_attributes("GERMAPARL", s_attribute = "year")

## ---- message = FALSE----------------------------------------------------
bt2008 <- partition("GERMAPARL", year = "2008")

## ---- message = FALSE----------------------------------------------------
bt2008 <- partition("GERMAPARL", year = 2008) # identisch mit vorhergehenden Beispiel

## ---- message = FALSE----------------------------------------------------
bt2009ff <- partition("GERMAPARL", year = 2009:2013)

## ---- message = FALSE----------------------------------------------------
bt2008 <- partition("GERMAPARL", year = 2008, interjection = FALSE)

## ---- collapse = TRUE----------------------------------------------------
s_attributes(bt2008, s_attribute = "role")

## ---- message = FALSE, collapse = TRUE-----------------------------------
bt2008min <- partition("GERMAPARL", year = 2008, interjection = FALSE, role = c("government", "mp"))

## ---- message = FALSE----------------------------------------------------
a <- partition("GERMAPARL", year = 2008)
b <- partition(a, interjection = FALSE)
c <- partition(b, role = c("mp", "government"))

## ---- message = FALSE----------------------------------------------------
size(bt2008min) == size(c)

## ---- message = FALSE----------------------------------------------------
bt2008min <- "GERMAPARL" %>% 
  partition(year = 2008) %>%
  partition(interjection = FALSE) %>%
  partition(role = c("mp", "government"))

## ---- message = FALSE, collapse = TRUE-----------------------------------
"GERMAPARL" %>% partition(year = 2008) %>% count(query = "Finanzmarktkrise")

## ---- message = FALSE, collapse = TRUE-----------------------------------
guttenberg <- partition(bt2008min, speaker = ".*Guttenberg", regex = TRUE)
s_attributes(guttenberg, "speaker")

## ---- message = FALSE, collapse = TRUE-----------------------------------
merkel2008 <- partition(bt2008min, speaker = "Merkel", regex = TRUE)
s_attributes(merkel2008, s_attribute = "speaker")

## ---- collapse = TRUE, message = FALSE-----------------------------------
merkel2008 <- partition(bt2008min, speaker = "Angela Merkel")
for (day in s_attributes(merkel2008, s_attribute = "date")){
  dt <- partition(merkel2008, date = day) %>% count(query = "Finanzmarktkrise")
  cat(sprintf("%s -> N Finanzkrise = %s\n", day, dt[["count"]]))
}

## ---- message = FALSE, eval = TRUE, echo = FALSE-------------------------
merkel_fcrisis <- partition(merkel2008, date = "2008-10-7")

## ---- message = FALSE, eval = FALSE--------------------------------------
#  merkel_fcrisis <- partition(merkel2008, date = "2008-10-7")
#  read(merkel_fcrisis)

## ---- message = FALSE----------------------------------------------------
writeLines(text = as.character(read(merkel_fcrisis)), con = "merkel.html")

## ---- collapse = TRUE, message = FALSE-----------------------------------
pre_nineeleven <- as.Date("2000-09-11")
nineten <- as.Date("2001-09-10")
nineeleven <- as.Date("2001-09-11")
post_nineeleven <- as.Date("2002-09-11")
pre <- partition("GERMAPARL", date = seq.Date(from = pre_nineeleven, to = nineten, by = "day"))
post <- partition("GERMAPARL", date = seq.Date(from = nineeleven, to = post_nineeleven, by = "day"))

count(pre, "Terrorismus")
count(post, "Terrorismus")

## ---- message = FALSE----------------------------------------------------
merkel2008 <- partition(bt2008min, speaker = "Angela Merkel")
merkel_speeches <- partition_bundle(merkel2008, s_attribute = "date")
summary(merkel_speeches)

## ---- message = FALSE, render = knit_print-------------------------------
count(merkel_speeches, query = c("Finanzmarktkrise", "Finanzmärkte", "Lehman")) %>% show()

