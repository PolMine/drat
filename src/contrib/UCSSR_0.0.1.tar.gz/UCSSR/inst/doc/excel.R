## ----install_recent_polmineR_version, eval = FALSE-----------------------
#  devtools::install_github("PolMine/polmineR", ref = "dev")

## ---- eval = FALSE-------------------------------------------------------
#  library(polmineR)
#  use("GermaParl")

## ---- eval = FALSE-------------------------------------------------------
#  result <- cooccurrences("GERMAPARL", query = "Islam")
#  store(result, filename = "~/Desktop/cooccurrences.xlsx")

## ---- eval = FALSE-------------------------------------------------------
#  result <- dispersion("GERMAPARL", query = "Islam", s_attribute = "year")
#  store(result, filename = "~/Desktop/dispersion.xlsx")

## ---- eval = FALSE-------------------------------------------------------
#  bt2008 <- partition("GERMAPARL", year = "2008", interjection = "FALSE", p_attribute = "word")
#  merkel2008 <- partition(
#    "GERMAPARL", year = "2008", speaker = "Angela Merkel", interjection = FALSE, p_attribute = "word"
#    )
#  merkel_terms <- features(bt2008, merkel2008, included = TRUE)
#  store(merkel_terms, filename = "~/Desktop/merkel_terms_2008.xlsx")

## ---- eval = FALSE-------------------------------------------------------
#  store(merkel_terms, filename = "~/Desktop/merkel_terms_2008.xlsx", rows = 1:50)

## ---- eval = FALSE-------------------------------------------------------
#  K <- kwic("GERMAPARL", "Flüchtlinge")
#  store(K, filename = "~/Desktop/kwic.xlsx")

## ------------------------------------------------------------------------
options("polmineR.mail" = "max.mustermann@uni-due.de") # Hier muss natürlich eine echte Adresse stehen!
options("polmineR.smtp_server" = "mail.uni-due.de")
options("polmineR.smtp_port" = "587")

## ---- eval = FALSE-------------------------------------------------------
#  mail(merkel_terms)
#  mail(K)
#  mail(K, rows = 1:50)

