#' Function to provide information about installed tutorials
#' and to execute interactive learnr tutorials.
#' @param name Name of a tutorial in the tutorial directory
#' @export

run_tutorial <- function(name = NULL) {
  if (is.null(name) || name %in% list.dirs(system.file("tutorials", package = "MigParl"), full.names = FALSE) == FALSE) {
    message("No valid tutorial name given. Please indicate which tutorial you want to run. Available tutorials are:")
    x <- list.dirs(system.file("tutorials", package = "MigParl"), full.names = FALSE)[list.dirs(system.file("tutorials", package = "MigParl"), full.names = FALSE) != ""]
    return(x)
  } else {
    learnr::run_tutorial(name, package = "MigParl")
  }
}
