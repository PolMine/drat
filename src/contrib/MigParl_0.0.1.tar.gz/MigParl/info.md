# Workflow

## Towards indexed CWB-Corpora

MigParl is essentially a consolidated, thematically subset subcorpus of a collection of plenary protocols of the German regional states. As such, the documentation of indexiation of the entire regional state corpora is at the location of this data, which is currently not available for public. 


>  PopParl/data-raw/00_plpr_to_cwb.Rmd

## From CWB to subset

### Topic Modelling

On the 16 individual collections of the German regional states a topic modelling was performed.

>  migparl_lda_models/data-raw/01_CWBToLDA.Rmd 

After that, topics were manually annotated (binary - relevant for migration and integration research or not). 

For that purpose, a utility package was used:

>  MPTE

after some data preparation:

>  migparl_lda_models/data-raw/01b_migparl_lda_selector_prep.Rmd

The output was enhanced by some counting and classification.

>  migparl_lda_models/data-raw/01c_lda_manual_labelling.Rmd

Result:

>  migparl_lda_models/desc/migparl_selected_topics.csv


### Subsetting

 In order to extract only relevant speeches from the initial corpora, we add two structural attributes to the corpus: speech and topic (which contains the 5 most relevant topics per speech). We then get the speeches, which belong to at least one of the previously identified state specific topic. After extracting the tokenstream and the metadata per regional state, the raw data is stored on disk for later reencoding.

 > MigParl/data-raw/02_SubsettingCorporaByTM.Rmd


### Reencoding

Previously extracted tokenstreams and metadata are encoded again.

> MigParl/data-raw/03_TokenstreamsToCWB.Rmd



 