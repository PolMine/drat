#' Download corpora from Web Directory.
#' 
#' \code{popparl_download_corpus} will get a tarball with the indexed corpus
#' from a directory (web dir) and install the corpus into the PopParl package.
#' @param corpus tarball Name of the corpus to install.
#' @param webdir (web) directory where the tarball resides.
#' @param archive logical; whether an older version of the corpus from the archive should be installed instead.
#' @param version if archive == TRUE, a corpus version must be specified.
#' @export popparl_download_corpus
#' @rdname install_popparl
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists
#'@examples
#'\dontrun{
#'popparl_download_corpus()
#'popparl_download_corpus("SL")
#'popparl_download_corpus(c("SL", "RP"))
#'popparl_download_corpus(corpus = "SL", archive = TRUE, version = "2019-03-13")
#'}

popparl_download_corpus <- function(corpus = c("BB", "BE", "BW", "BY", "HB", "HE", "HH", "MV", "NI", "NW", 
                                               "RP", "SH", "SL", "SN", "ST", "TH"), webdir = "https://polmine.sowi.uni-due.de/corpora/cwb/fedparl", user = NULL, password = NULL,  archive = FALSE, version = NULL) {
    
    if (archive == TRUE && is.null(version)) stop("... if archive is TRUE, then corpus version must be specified!")
    
    if (length(corpus) == 1L){
      if (archive == FALSE) {
      tarball <- file.path(webdir, sprintf("%s.tar.gz", tolower(corpus)))
      } else {
        webdir = "https://polmine.sowi.uni-due.de/corpora/cwb/fedparl/archive"
        tarball <- file.path(webdir, sprintf("%s_%s.tar.gz", tolower(corpus), version))
      }
      if (is.null(user)){
        if (Sys.getenv("RSTUDIO") == "1") user <- rstudioapi::showPrompt("Name", "Please enter your user name") else user <- readline(prompt = "Please enter your user name: ")   
      }
      if (is.null(password)){
        if (Sys.getenv("RSTUDIO") == "1") password <- rstudioapi::askForPassword() else password <- readline(prompt = "Please enter password: ")
      }
      
      message("... downloading tarball: ", tarball)
      cwbtools::corpus_install(pkg = "PopParl", tarball = tarball, user = user, password = password)
      
    } else {
      if (missing(corpus)) corpus <- c("BB", "BE", "BW", "BY", "HB", "HE", "HH", "MV", "NI", "NW", 
                                       "RP", "SH", "SL", "SN", "ST", "TH")
      if (is.null(user)){
        if (Sys.getenv("RSTUDIO") == "1") user <- rstudioapi::showPrompt("Name", "Please enter your user name") else user <- readline(prompt = "Please enter your user name: ")   
      }
      if (is.null(password)){
        if (Sys.getenv("RSTUDIO") == "1") password <- rstudioapi::askForPassword() else password <- readline(prompt = "Please enter password: ")
      }
      
      for (x in corpus) popparl_download_corpus(corpus = x, webdir = webdir, user = user, password = password, archive = archive, version = version)
    }
}
