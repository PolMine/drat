#' Download and load supplementary data from web directory.
#' 
#' \code{popparl_download_lda_model} will download a lda topic model
#' from a directory (web dir) and store it in the PopParl package.
#' \code{popparl_download_global_vectors} will download a global vectors model
#' from a directory (web dir) and store it in the PopParl package.
#' @param model Name of the model.
#' @param webdir (web) directory where the data file resides
#' @export popparl_download_lda_model
#' @export popparl_download_global_vectors

#' @rdname supplementary_data


popparl_download_lda_model <- function(model = NULL,
                                     webdir = "https://polmine.sowi.uni-due.de/corpora/cwb/fedparl/supplementary_data/topicmodels",
                                     user = NULL,
                                     password = NULL) {

  rds_file <- model

  
  if (is.null(user)) {
        if (Sys.getenv("RSTUDIO") == "1") user <- rstudioapi::showPrompt("Name", "Please enter your user name") else user <- readline(prompt = "Please enter your user name: ")   
  }
  if (is.null(password)) {
        if (Sys.getenv("RSTUDIO") == "1") password <- rstudioapi::askForPassword() else password <- readline(prompt = "Please enter password: ")
  }
  
  if (length(model) == 1) {
    tarball <- file.path(webdir, rds_file)
    message("... downloading supplementary data: ", basename(tarball))
    prefix <- gsub("^(https://|http://).*?$", 
                   "\\1", tarball)
    tarball <- gsub("^(https://|http://)(.*?)$", 
                    "\\2", tarball)
    download.file(url = sprintf("%s%s:%s@%s", 
                                prefix, user, password, tarball), destfile = paste0(file.path(system.file(package = "PopParl", "extdata", "supplementary_data", "topicmodels")), "/", 
                                                                                    rds_file))
  } else {
    for (x in model) popparl_download_lda_model(model = x, webdir = webdir, user = user, password = password)
  }
}

popparl_download_global_vectors <- function(model = NULL,
                                     webdir = "https://polmine.sowi.uni-due.de/corpora/cwb/fedparl/supplementary_data/global_vectors",
                                     user = NULL,
                                     password = NULL) {

  rds_file <- model

  
  if (is.null(user)) {
        if (Sys.getenv("RSTUDIO") == "1") user <- rstudioapi::showPrompt("Name", "Please enter your user name") else user <- readline(prompt = "Please enter your user name: ")   
  }
  if (is.null(password)) {
        if (Sys.getenv("RSTUDIO") == "1") password <- rstudioapi::askForPassword() else password <- readline(prompt = "Please enter password: ")
  }
  
  if (length(file) == 1) {
    tarball <- file.path(webdir, rds_file)
    message("... downloading supplementary data: ", basename(tarball))
    prefix <- gsub("^(https://|http://).*?$", 
                   "\\1", tarball)
    tarball <- gsub("^(https://|http://)(.*?)$", 
                    "\\2", tarball)
    download.file(url = sprintf("%s%s:%s@%s", 
                                prefix, user, password, tarball), destfile = paste0(file.path(system.file(package = "PopParl", "extdata", "supplementary_data", "global_vectors")), "/", 
                                                                                    rds_file))
  } else {
    for (x in file) popparl_download_global_vectors(model = x, webdir = webdir, user = user, password = password)
  }
}