library(testthat)
library(jobstatus)

test_check("jobstatus")
