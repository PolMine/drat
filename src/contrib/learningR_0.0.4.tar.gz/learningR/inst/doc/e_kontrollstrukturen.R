## ----eval=TRUE----------------------------------------------------------------
schokolade <- c("milka", "lindt", "ritter-sport", "alpia", "schogetten")
schokolade[4] == "alpia"

## -----------------------------------------------------------------------------
if (schokolade[5] != "alpia"){
  print("her mit dem zeug")
} else {
  print("bleib mir weg damit")
}


## ----eval = FALSE-------------------------------------------------------------
#  for (i in c(1,2,3,4,5)) print(i) # auch für character vectors, logische vektoren

## ---- eval = FALSE------------------------------------------------------------
#  for (i in 1:5){ print(i) }

## ---- eval = FALSE------------------------------------------------------------
#  for (i in c("a", "b", "c")){ print(i) }

## ---- eval = FALSE------------------------------------------------------------
#  for (schoki in schokolade) print(schoki)

## ---- eval = FALSE------------------------------------------------------------
#  for (i in 1:length(schokolade)) print(schokolade[i])

## -----------------------------------------------------------------------------
for (schoki in schokolade){
  if (schoki == "alpia"){
    print("großer jubel")
  } else {
    print("weg damit!!!!")
  }  
}

## -----------------------------------------------------------------------------
add_one <- function(x){x + 1}
add_one(1)

## -----------------------------------------------------------------------------
add_anything <- function(x, y){x + y}
add_anything(5, 5)

## -----------------------------------------------------------------------------
add_anything_default <- function(x, y = 2){
  x + y
}
add_anything_default(x = 5)
add_anything_default(x = 5, 3)
add_anything_default(x = 5, y = 6)

## -----------------------------------------------------------------------------
tab <- read.table(
  "https://opendata-duisburg.de/sites/default/files/Corona%2030.04.2020.csv",
  sep = ";"
)
tab[1:5,]

## ---- eval = FALSE------------------------------------------------------------
#  library(magrittr)
#  tab <- read.table("https://opendata-duisburg.de/sites/default/files/Corona%2030.04.2020.csv", sep = ";", header = TRUE)
#  tab[["Datum"]] <- as.Date(tab[["Datum"]], format = "%d.%m.%Y ")
#  tab %>%
#    subset(Datum >= as.Date("2020-04-01")) %>%
#    barplot(height = .[["X.Aktuell.infiziert"]])

## -----------------------------------------------------------------------------
lapply(1:3, function(x){x + 1})
sapply(1:3, function(x){x + 1})

## ---- eval = FALSE------------------------------------------------------------
#  pdf(file = tempfile())

## ---- eval = FALSE------------------------------------------------------------
#  dev.off()

