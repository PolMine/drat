## -----------------------------------------------------------------------------
head(list.files(.libPaths()[1]))

## -----------------------------------------------------------------------------
path.expand("~")

## -----------------------------------------------------------------------------
tempdir()
tempfile()

## ---- eval = TRUE-------------------------------------------------------------
excel_online <- "https://opendata-duisburg.de/sites/default/files/Corona%2030.04.2021.xlsx"
data <- openxlsx::read.xlsx(xlsxFile = excel_online)

## ---- eval = TRUE-------------------------------------------------------------
library(readr)
data[[1]] <- parse_date(gsub("\u00A0", "", data[[1]]), format = "%d.%m.%Y", trim_ws = TRUE)
purge <- function(x){
  loc <- readr::locale(grouping_mark = ".")
  readr::parse_number(x, locale = loc, trim_ws = TRUE, na = "\u00A0\u00A0")
}
for (col in colnames(data[2:ncol(data)])) data[[col]] <- purge(data[[col]])

## ---- echo = FALSE, eval = FALSE----------------------------------------------
#  DT::datatable(data, options = list(pageLength = 8L), rownames = FALSE)

## -----------------------------------------------------------------------------
head(data, 15)

## -----------------------------------------------------------------------------
library(readr)
tab_csv <- readr::read_delim(
  file = "https://opendata-duisburg.de/sites/default/files/Corona%2030.04.2021.csv",
  col_types = cols(col_date(format = "%d.%m.%Y"), col_number(), col_number(), col_number(), col_number()),
  locale = locale(decimal_mark = ",", grouping_mark = "."),
  delim = ";",
  na = c("", "\u00A0")
)

## -----------------------------------------------------------------------------
sapply(
  2:ncol(data),
  function(i) identical(sum(data[[i]], na.rm = TRUE), sum(tab_csv[[i]], na.rm = TRUE))
)

## -----------------------------------------------------------------------------
json_url <- "https://opendata-duisburg.de/api/action/datastore/search.json?resource_id=00766064-4cab-4f40-8f67-82ec6b14d6ca"
json_data <- jsonlite::fromJSON(json_url)
tab <- json_data$result$records
for (i in 2:ncol(tab)) tab[[i]] <- as.integer(tab[[i]])
head(tab, n = 3)

## -----------------------------------------------------------------------------
tail(tab, n  = 3)

