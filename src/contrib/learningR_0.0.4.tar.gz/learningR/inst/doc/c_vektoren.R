## ---- eval = FALSE------------------------------------------------------------
#  install.packages("tm")
#  install.packages("polmineR")

## ---- eval = FALSE------------------------------------------------------------
#  install.packages("drat") # creation and use of CRAN-like repos
#  drat::addRepo("polmine")
#  getOption("repos")
#  install.packages("gles")

## -----------------------------------------------------------------------------
logo <- c(T, F, F, T)
logo <- c(TRUE, FALSE, FALSE, TRUE) # mehr Tipparbeit, aber expressiver

## -----------------------------------------------------------------------------
fgw_exp <- c(39, 16, 9, 5, 7, 18, 6)

## -----------------------------------------------------------------------------
parties <- c("CDU/CSU", "SPD", "AfD", "FDP", "LINKE", "GRÜNE", "Sonstige")
party_colors <- c("black", "red", "blue", "yellow", "pink", "green", "grey")

## -----------------------------------------------------------------------------
a <- 1:5 # eine Zahlenreihe
b <- 6:10 # eine zweite Zahlenreihe

## -----------------------------------------------------------------------------
x <- c(a, b) # numerische Vektoren verknüpfen ("c"für combine)
head(x) # Anfang eines Vektors ansehen
tail(x) # Ende eines Vektors ansehen

## -----------------------------------------------------------------------------
is.numeric(x) # Auf Klasse 'numeric' prüfen - vgl. is.character() etc.

## -----------------------------------------------------------------------------
as.numeric(logo) # Typ-Umwandlung von logisch nach numerisch
as.character(fgw_exp)

## -----------------------------------------------------------------------------
rep(3, times = 4) # einfache Wiederholung
rep(c(1,2,3), times = 2) # Wiederholung einer Reihe

## -----------------------------------------------------------------------------
a <- c(1,2,3)
b <- c(4,5,6)
a + b
a * b
a / b

## -----------------------------------------------------------------------------
sum(fgw_exp) # auch: mean(fgw_exp), sd(fgw_exp)

## -----------------------------------------------------------------------------
names(fgw_exp) <- parties # Zuweisung von Namen
fgw_exp

## -----------------------------------------------------------------------------
fgw_exp <- c(
  "CDU/CSU" = 39, # Anführungszeichen, wenn Zeichen wie ()[]! etc. enthalten
  SPD = 16,
  AfD = 9,
  FDP = 5,
  LINKE = 7,
  GRÜNE = 18, # Umlaute (und Sonderzeichen) können unendlich tückisch sein ...
  Sonstige = 6
)
fgw_exp

## -----------------------------------------------------------------------------
barplot(height = fgw_exp)

## -----------------------------------------------------------------------------
barplot(height = fgw_exp, names.arg = names(fgw_exp), col = party_colors)

## -----------------------------------------------------------------------------
spd <- fgw_exp[2] # nur SPD
fgw_exp[1:6] # ohne "Sonstige"
centre_left <- fgw_exp[c("SPD", "LINKE", "GRÜNE")] # 

## -----------------------------------------------------------------------------
sum(centre_left)
sum(fgw_exp[c("CDU/CSU", "FDP")])

## -----------------------------------------------------------------------------
fgw_exp["CDU/CSU"] >= 30
fgw_exp["FDP"] < 5

## -----------------------------------------------------------------------------
fgw_exp > 10
fgw_exp[fgw_exp > 10]

## -----------------------------------------------------------------------------
length(fgw_exp) # wichtig, um durch Werte zu iterieren - 1:length(fgw_exp)
order(fgw_exp) # Reihenfolge
order(fgw_exp, decreasing = TRUE) # wie könnte das noch gemacht werden?
fgw_exp[order(fgw_exp, decreasing = TRUE)]

## -----------------------------------------------------------------------------
max(fgw_exp) # Maximalwert
min(fgw_exp) # minimaler Wert
mean(fgw_exp) # Mittelwert
sd(fgw_exp) # Standardabweichung

## -----------------------------------------------------------------------------
which(fgw_exp == max(fgw_exp))
fgw_exp[which(fgw_exp == max(fgw_exp))]
fgw_exp[which(fgw_exp > 10)]

## ---- eval = FALSE------------------------------------------------------------
#  library(polmineR)
#  words <- get_token_stream("GERMAPARLMINI", p_attribute = "word")
#  length(words)
#  head(words)
#  head(toupper(words))
#  tolower(words) %>% head()

## ---- eval = FALSE------------------------------------------------------------
#  wordcount <- table(words)
#  head(wordcount)

## ---- eval = FALSE------------------------------------------------------------
#  stopwords <- tm::stopwords("de")
#  detect_stopwords <- words %in% stopwords
#  word_count <- table(words[!words %in% stopwords]) # Negation durch !
#  tail(word_count)

## ---- eval = FALSE------------------------------------------------------------
#  noise <- c(",", ".", ":", ")", "(", "/", "-", "!", "[", "]", "?", ";", '"')
#  word_count_denoised <- word_count[!names(word_count) %in% noise]
#  head(word_count_denoised)
#  word_count_sorted <- word_count_denoised[order(word_count_denoised, decreasing = TRUE)]
#  head(word_count_sorted, 10)

## ---- eval = FALSE------------------------------------------------------------
#  wordcloud::wordcloud(
#    words = names(word_count_sorted)[1:50], freq = unname(word_count_sorted)[1:50],
#    colors = rep(palette(), 10)[1:50]
#  )

## -----------------------------------------------------------------------------
as.factor(parties)

## -----------------------------------------------------------------------------
combn(parties, 2)[,1:5] # (hypothetische) Zweier-Koalitionen

## -----------------------------------------------------------------------------
constituencies <- c(202L, 304L, 20L)

## -----------------------------------------------------------------------------
foo <- c(NA, 3, 7, NA, 4)
foo
is.na(foo) # auf NA testen
sum(foo)
sum(foo, na.rm = TRUE) # NA-Werte aus Summenbildung ausschließen

