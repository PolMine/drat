## ---- load_refs, include=FALSE, cache=FALSE-----------------------------------
library(RefManageR)
BibOptions(check.entries = FALSE,
           bib.style = "authoryear",
           cite.style = "authoryear",
           style = "markdown",
           hyperlink = FALSE,
           dashed = FALSE)
myBib <- ReadBib("./readings.bib", check = FALSE)

## ---- eval = FALSE------------------------------------------------------------
#  remotes::install_github("ablaette/learningR") # Installation der aktuellen Version

## ---- eval = TRUE-------------------------------------------------------------
library(learningR)
dim(corona_by_county)

## ---- eval = FALSE------------------------------------------------------------
#  browseVignettes(package = "learningR")

## ---- eval = FALSE------------------------------------------------------------
#  learningR::open_rmd_file()

## -----------------------------------------------------------------------------
income <- corona_by_county[["income"]]

## -----------------------------------------------------------------------------
mean(income, na.rm = TRUE)
sd(income, na.rm = TRUE)
c(min = min(income, na.rm = TRUE), max = max(income, na.rm = TRUE))

## ---- fig.height = 6, fig.width = 10------------------------------------------
hist(corona_by_county[["income"]])

## -----------------------------------------------------------------------------
by_county_data <- subset(corona_by_county, !is.na(region))

## -----------------------------------------------------------------------------
regions <- unique(by_county_data[["region"]])

## -----------------------------------------------------------------------------
county_data_aggr_li <- list()
for (buland in regions){
  corona_by_county_min <- subset(corona_by_county, region == buland)
  county_data_aggr_li[[buland]] <- data.frame(
    mean = mean(corona_by_county_min[["agequot"]], na.rm = TRUE),
    sd = sd(corona_by_county_min[["agequot"]], na.rm = TRUE)
  )
}
county_data_aggr <- do.call(rbind, county_data_aggr_li)
head(county_data_aggr, 3)

## -----------------------------------------------------------------------------
regions <- unique(by_county_data[["region"]])

## -----------------------------------------------------------------------------
county_data_aggr_li <- lapply(
  regions,
  function(buland){
    corona_by_county_min <- subset(corona_by_county, region == buland)
    data.frame(
      region = buland,
      mean = mean(corona_by_county_min[["agequot"]], na.rm = TRUE),
      sd = sd(corona_by_county_min[["agequot"]], na.rm = TRUE)
    )
  }
)
county_data_aggr <- do.call(rbind, county_data_aggr_li)
head(county_data_aggr, 3)

## -----------------------------------------------------------------------------
library(dplyr, quietly = TRUE, warn.conflicts = FALSE)
corona_by_county %>%
  filter(!is.na(region)) %>%
  group_by(region) %>%
  summarise(mean = mean(agequot), sd = sd(agequot)) %>%
  head(6)

## -----------------------------------------------------------------------------
library(data.table, warn.conflicts = FALSE)
dt <- data.table(corona_by_county)
dt[!is.na(region), list(mean = mean(.SD$agequot), sd = sd(.SD$agequot)), by = "region"]

## ---- fig.height = 6, fig.width = 10------------------------------------------
boxplot(agequot ~ region , data = by_county_data, las = 2)

## ---- fig.height = 6, fig.width = 10------------------------------------------
lattice::histogram(~ afd | region, data = corona_by_county)

## ---- fig.height = 6, fig.width = 10------------------------------------------
library(lattice)
vars <- c("cases7_per_100k", "foreign_pop_share", "afd", "income", "per_km2", "agequot")
lattice::splom(~ corona_by_county[, vars], data = corona_by_county)

## -----------------------------------------------------------------------------
r <- lm(cases7_per_100k ~ afd, data = by_county_data)

## ---- echo = TRUE-------------------------------------------------------------
summary(r)

## -----------------------------------------------------------------------------
str(summary(r))

## ---- fig.height = 6, fig.width = 10------------------------------------------
plot(by_county_data$afd, by_county_data$cases7_per_100k)
abline(r)

## -----------------------------------------------------------------------------
normalize <- function(x) (max(x, na.rm = TRUE) - x) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE))
by_county_data_norm <- mutate(
  .data = by_county_data,
  cases7_per_100k = normalize(cases7_per_100k),
  foreign_pop_share = normalize(foreign_pop_share),
  afd = normalize(afd), income = normalize(income),
  per_km2 = normalize(per_km2), agequot = normalize(agequot)
)

## -----------------------------------------------------------------------------
vars <- c("cases7_per_100k", "foreign_pop_share", "afd", "income", "per_km2", "agequot")
normalize_col <- function(x){
  x <- by_county_data[[x]]
  (max(x, na.rm = TRUE) - x) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE))
}
df_norm <- data.frame(lapply(setNames(vars, vars), normalize_col))

## -----------------------------------------------------------------------------
m1 <- lm(cases7_per_100k ~ foreign_pop_share, data = by_county_data_norm)
m2 <- lm(cases7_per_100k ~ foreign_pop_share + income, data = by_county_data_norm)
m3 <- lm(cases7_per_100k ~ foreign_pop_share + income + afd, data = by_county_data_norm)
m4 <- lm(
  cases7_per_100k ~ foreign_pop_share + income + afd + agequot + per_km2,
  data = by_county_data_norm
)

## ---- eval = FALSE------------------------------------------------------------
#  stargazer::stargazer(
#    m1, m2, m3, m4,
#    dep.var.labels.include = FALSE, type = "html", align = TRUE, single.row = TRUE, column.sep.width = "1pt",
#    omit.stat = c("n", "rsq", "f", "ser")
#  )

## ---- results = "asis", echo = FALSE------------------------------------------
s <- stargazer::stargazer(m1, m2, m3, m4, dep.var.labels.include = FALSE, title = "Results", type = "html", align = TRUE, font.size = "tiny", single.row = TRUE, column.sep.width = "1pt", omit.stat = c("n", "rsq", "f", "ser"))

## ----refs, echo = FALSE, results = "asis"-------------------------------------
NoCite(myBib, "DiscoveringStatistics")
PrintBibliography(myBib)

