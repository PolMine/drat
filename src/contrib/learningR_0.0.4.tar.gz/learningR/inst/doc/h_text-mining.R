## ---- eval = TRUE-------------------------------------------------------------
df <- read.csv(
  file = "https://opendata-duisburg.de/sites/default/files/MHGo2018_2.csv",
  sep = ";"
)

## ---- eval = FALSE------------------------------------------------------------
#  btw17_url <- "https://www.bundeswahlleiter.de/dam/jcr/72f186bb-aa56-47d3-b24c-6a46f5de22d0/btw17_kerg.csv"
#  btw17_local <- tempfile()
#  download.file(url = btw17_url, destfile = btw17_local)
#  btw17_aux <- scan(file = btw17_local, what = character(), sep = "\n")
#  df <- read.csv(file = btw17_local, sep = ";", skip = 5)

## ---- eval = TRUE-------------------------------------------------------------
library(rvest)
library(xml2)

wikipedia_url <- "https://de.wikipedia.org/wiki/Liste_der_Mitglieder_des_Deutschen_Bundestages_%2816._Wahlperiode%29"
page <- xml2::read_html(wikipedia_url)
tables <- rvest::html_nodes(page, "table")
tab <- rvest::html_table(tables[[2]])

## -----------------------------------------------------------------------------
head(tab[,1:3])

## ---- eval = FALSE------------------------------------------------------------
#  mean(2005 - as.integer(tab[,2])) # NOT WORKING

## -----------------------------------------------------------------------------
pm <- "http://www.bundesregierung.de/Content/DE/Pressemitteilungen/BPA/2015/07/2015-07-09-bkm-kulturelle-bildung.html"
page <- xml2::read_html(pm)

## -----------------------------------------------------------------------------
paragraph_nodes <- rvest::html_nodes(page, xpath = "//p") # Identifikation aller Absätze
paragraphs <- sapply(paragraph_nodes, html_text) # Extraktion des Texts aus den Absätzeen
paragaphs <- paragraphs[nchar(paragraphs) > 0L] # Absätze ohne Text fallen lassen
paragaphs[1]

## ---- eval = FALSE------------------------------------------------------------
#  url_ltw <- "https://www.bundeswahlleiter.de/dam/jcr/a333e523-0717-42ad-a772-d5ad7e7e97cc/ltw_erg_gesamt.pdf"
#  ltw_local <- tempfile()
#  pdf_local <- download.file(url = url_ltw, destfile = ltw_local)

## ---- eval = FALSE------------------------------------------------------------
#  library(tabulizer)
#  tabulizer::extract_tables(file = ltw_local, pages = 74)

## ---- eval = FALSE------------------------------------------------------------
#  cdu_btw2017 <- "https://www.cdu.de/system/tdf/media/dokumente/170703regierungsprogramm2017.pdf?file=1"
#  cdu_btw2017_local <- tempfile()
#  download.file(url = cdu_btw2017, destfile = cdu_btw2017_local)

## ---- eval = FALSE------------------------------------------------------------
#  library(pdftools)
#  pdftools::pdf_info(cdu_btw2017_local)
#  txt <- pdftools::pdf_text(cdu_btw2017_local)

## ---- eval = FALSE------------------------------------------------------------
#  txt2 <- gsub("\\s{6,}\\d+", "", txt)
#  txt3 <- gsub("\\n", " ", txt2)
#  txt4 <- gsub("\\s+", " ", txt3)# große Lücken weg
#  txt5 <- gsub("", " ", txt4) # Kästchen weg
#  txt6 <- gsub("-\\s+(?!und)", "", txt5, perl = TRUE) # Bundestriche weg

## ---- eval = FALSE------------------------------------------------------------
#  word_list <- strsplit(x = txt6, split = "\\s")
#  words <- unlist(word_list)

## ---- eval = FALSE------------------------------------------------------------
#  words_cleaned <- gsub("[,:\\.!?]", "", words)
#  words_cleaned <- tolower(words_cleaned)
#  words_cleaned <- words_cleaned[!words_cleaned %in% tm::stopwords("de")]
#  words_count <- table(words_cleaned)
#  words_count_sorted <- words_count[order(words_count, decreasing = TRUE)]

## ---- eval = FALSE------------------------------------------------------------
#  library(wordcloud)
#  
#  wordcloud(
#    words = names(words_count_sorted)[1:50],
#    freq = unname(words_count_sorted)[1:50]
#  )

## ---- eval = FALSE------------------------------------------------------------
#  install.packages("tm")

## -----------------------------------------------------------------------------
library(tm)
stopwords("german")

## -----------------------------------------------------------------------------
sentence <- c("Das", "ist", "ein", "Satz", "mit", "vielen", "Füllwörtern", ".")
interpunctation <- c(".", ",", "?", "!", ":", ";")
to_remove <- c(interpunctation, stopwords("german"))

sentence_lowered <- tolower(sentence)
sentence_filtered <- sentence[!sentence_lowered %in% to_remove]

## -----------------------------------------------------------------------------
sentence_filtered <- character()
for (word in sentence_lowered){
  if (word %in% to_remove){
    print("word")
    print("Das ist ein Stopword! Weg damit!")
  } else {
    print("Das behalte ich!")
    sentence_filtered <- c(sentence_filtered, word)
  }
}

