## ---- load_refs, include=FALSE, cache=FALSE-----------------------------------
library(RefManageR)
BibOptions(check.entries = FALSE,
           bib.style = "authoryear",
           cite.style = "authoryear",
           style = "markdown",
           hyperlink = FALSE,
           dashed = FALSE)
myBib <- ReadBib("./readings.bib", check = FALSE)

## ----refs, echo = FALSE, results = "asis"-------------------------------------
PrintBibliography(myBib)

