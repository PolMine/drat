# MigParl Corpus of Plenary Protocols (build 2018-10-30)

#### About

The MigParl Corpus constitutes a thematically subset collection of the plenary protocols of the German regional states, concerned with migration and integration. The corpus has been prepared in the [PolMine Project](http://polmine.github.io). This version of the corpus is based on pdf documents issued by the respective parliament. As part of the corpus preparation pipeline, the data has been linguistically annotated (using Stanford NLP and the treetagger) and imported into the Corpus Workbench (CWB). 

MigParlMini is a sample corpus of MigParl and comes within the R package. It provides the same general features, but has only 1% of the coverage of the full-grown MigParl corpus.

#### License

The data comes with a CLARIN PUB+BY+NC+SA license, as an explanation of the license, see [CLARIN licenses](https://www.clarin.eu/content/license-categories). 

#### Quotation


#### Feedback

