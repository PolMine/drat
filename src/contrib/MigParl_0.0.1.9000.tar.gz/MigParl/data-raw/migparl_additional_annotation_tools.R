migparl_add_s_attribute_speech <- function(corpus, mc = 4L, progress = TRUE, package){
  speeches <- as.speeches(
    corpus, gap = 500, mc = mc, progress = progress,
    s_attribute_date = "date", s_attribute_name = "speaker"
  )
  
  regions_list <- lapply(
    speeches@objects,
    function(x){
      dt <- data.table(x@cpos)
      dt[["speech"]] <- x@name
      dt
    }
  )
  
  dt <- data.table::rbindlist(regions_list)
  setnames(dt, old = c("V1", "V2"), new = c("cpos_left", "cpos_right"))
  dt[, "cpos_left" := as.integer(dt[["cpos_left"]]) ]
  dt[, "cpos_right" := as.integer(dt[["cpos_right"]]) ]
  setorderv(dt, cols = "cpos_left", order = 1L)
  corpus_charset <- cwbtools::registry_file_parse(corpus = corpus)[["properties"]][["charset"]]
  germaparl_data_dir <- cwbtools::registry_file_parse(corpus = corpus)[["home"]]
  
  cwbtools::s_attribute_encode(
    values = dt[["speech"]], # is still UTF-8, recoding done by s_attribute_encode
    data_dir = germaparl_data_dir,
    s_attribute = "speech",
    corpus = corpus,
    region_matrix = as.matrix(dt[, c("cpos_left", "cpos_right")]),
    registry_dir = set_regdir(package),
    encoding = corpus_charset,
    method = "CWB",
    verbose = TRUE, 
    delete = TRUE
    )
  
  invisible(dt)
}



migparl_encode_lda_topics <- function(corpus = corpus, model, k = 250, n = 5, package){
  
  data_dir <- cwbtools::registry_file_parse(corpus = corpus, registry_dir = set_regdir(package))[["home"]]
  corpus_charset <- cwbtools::registry_file_parse(corpus = corpus)[["properties"]][["charset"]]
  
  model <- model
  
  message("... getting topic matrix")
  topic_matrix <- topicmodels::topics(model, k = n)
  topic_dt <- data.table(
    speech = colnames(topic_matrix),
    topics = apply(topic_matrix, 2, function(x) sprintf("|%s|", paste(x, collapse = "|"))),
    key = "speech"
  )
  
  message("... decoding s-attribute speech")
  if (!"speech" %in% s_attributes(corpus)){
    stop("The s-attributes 'speech' is not yet present.",
         "Use the function add_s_attribute_speech to generate it.")
  }
  cpos_dt <- decode(corpus, s_attribute = "speech")
  setkeyv(cpos_dt, "speech")
  
  
  ## Merge tables
  cpos_dt2 <- topic_dt[cpos_dt]
  setorderv(cpos_dt2, cols = "cpos_left", order = 1L)
  cpos_dt2[["speech"]] <- NULL
  cpos_dt2[["id"]] <- NULL
  cpos_dt2[, topics := ifelse(is.na(topics), "||", topics)]
  setcolorder(cpos_dt2, c("cpos_left", "cpos_right", "topics"))
  
  # some sanity tests
  message("... running some sanity checks")
  coverage <- sum(cpos_dt2[["cpos_right"]] - cpos_dt2[["cpos_left"]]) + nrow(cpos_dt2)
  if (coverage != size(corpus)) stop()
  P <- partition(corpus, speech = ".*", regex = TRUE)
  if (sum(cpos_dt2[["cpos_left"]] - P@cpos[,1]) != 0) stop()
  if (sum(cpos_dt2[["cpos_right"]] - P@cpos[,2]) != 0) stop()
  if (length(sAttributes(corpus, "speech", unique = FALSE)) != nrow(cpos_dt2)) stop()
  
  message("... encoding s-attribute 'topics'")
  cwbtools::s_attribute_encode(
    values = cpos_dt2[["topics"]], # is still UTF-8, recoding done by s_attribute_encode
    data_dir = data_dir,
    s_attribute = "topics",
    corpus = corpus,
    region_matrix = as.matrix(cpos_dt2[, c("cpos_left", "cpos_right")]),
    registry_dir = set_regdir(package),
    encoding = corpus_charset,
    method = "R",
    verbose = TRUE, 
    delete = TRUE
    )
}

set_regdir <- function(package){
  system.file(package = package, "extdata", "cwb", "registry")
}


topic_regexR <- function(topics = mig_int_topics, topic_pattern = "^.*\\|X\\|.*$") {
  S2 <- strsplit(topics, "|", fixed = TRUE)[[1]]
  topic_regex <- as.character()
  for (topic in S2) topic_regex <- paste0(topic_regex,  gsub("X", topic, topic_pattern), sep = "|")
  topic_regex <- substr(topic_regex, 1, nchar(topic_regex)-1)
  topic_regex <- sprintf("(%s)", topic_regex)
  
  return(topic_regex)
}
