# 0.1.3.9001 (2019-10-10)
* First code block in vignette is not executed, to make package installable. 

# 0.1.3 (2019-10-08)
* corpus news
  * PLPRBTPDF made available with plprbtpdf_download_corpus() 

# 0.1.2 (2019-03-23)
* corpus news
	* new default corpora (build 2019-03-25)
* package
	* added functionality to download older versions of the corpora (2019-03-13)
	* added download_global_vectors to download_supplementary_data 

* added lea topic models based on the 2019-03-25 corpus
	* lda_BB_2019-03-25_250_2019-03-25.rds
	* lda_BE_2019-03-25_250_2019-03-25.rds
	* lda_BW_2019-03-25_250_2019-03-25.rds
	* lda_BY_2019-03-25_250_2019-03-25.rds
	* lda_HB_2019-03-25_250_2019-03-25.rds
	* lda_HE_2019-03-25_250_2019-03-27.rds
	* lda_HH_2019-03-25_250_2019-03-25.rds
	* lda_MV_2019-03-25_250_2019-03-27.rds
	* lda_NI_2019-03-25_250_2019-03-27.rds
	* lda_NW_2019-03-25_250_2019-03-27.rds
	* lda_RP_2019-03-25_250_2019-03-27.rds
	* lda_SH_2019-03-25_250_2019-03-27.rds
	* lda_SL_2019-03-25_250_2019-03-27.rds
	* lda_SN_2019-03-25_250_2019-03-27.rds
	* lda_ST_2019-03-25_250_2019-03-27.rds
	* lda_TH_2019-03-25_250_2019-05-10.rds




# 0.1.1 (2019-03-18)
* added lda topic models based on the template of the [topicanalysis](https://github.com/PolMine/topicanalysis) package
	* lda_BB_2019-03-13_250_2019-03-15.rds
	* lda_BE_2019-03-13_250_2019-03-15.rds
	* lda_BW_2019-03-13_250_2019-03-15.rds
	* lda_BY_2019-03-13_250_2019-03-15.rds
	* lda_HB_2019-03-13_250_2019-03-15.rds
	* lda_HE_2019-03-13_250_2019-03-16.rds
	* lda_HH_2019-03-13_250_2019-03-15.rds
	* lda_MV_2019-03-13_250_2019-03-16.rds
	* lda_NI_2019-03-13_250_2019-03-16.rds
	* lda_NW_2019-03-13_250_2019-03-16.rds
	* lda_RP_2019-03-13_250_2019-03-16.rds
	* lda_SH_2019-03-13_250_2019-03-17.rds
	* lda_SL_2019-03-13_250_2019-03-16.rds
	* lda_SN_2019-03-13_250_2019-03-17.rds
	* lda_ST_2019-03-13_250_2019-03-17.rds
	* lda_TH_2019-03-13_250_2019-03-17.rds

# PopParl 0.1.0 (2019-03-15)

* general
	- fixed small mistakes, missing speakers, etc.

* coverage
	- extended coverage for all corpora until the end of 2018
	- extended coverage for NW (own OCR) for legislative period 13
	- extended coverage for HE based on doc files

* s_attributes
	- enhanced governmental and presidency speakers for party affiliation
	- harmonized speaker format (full name, no title)

* p_attributes
	- added named entity recognition as positional attribute

* format
	- encoding changed from UTF-8 to latin1  

* package
	- added popparl_download_lda_model function



# 2018-10-01

Initial version. 