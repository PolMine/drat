#' WELT Corpus
#' 
#' @keywords package
#' @docType package
#' @rdname welt
#' @name welt
NULL

 
#' @details \code{welt_download_corpus} will get a tarball with the indexed corpus
#' from a directory (web dir) and install the corpus into the \code{welt} package.
#' @param tarball Name of the tarball.
#' @param webdir (web) directory where the tarball resides
#' @export welt_download_corpus
#' @rdname welt
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists
welt_download_corpus <- function(tarball = "welt.tar.gz", webdir = "https://s3.eu-central-1.amazonaws.com/polmine/corpora/cwb/welt"){
  tarball <- file.path(webdir, tarball)
  message("... downloading tarball: ", tarball)
  corpus_install(pkg = "welt", tarball = tarball)
}
