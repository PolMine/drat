## The German Longitudinal Election Study (GLES) as a R package 

Prepared for teaching purposes at the University of Duisburg-Essen.
