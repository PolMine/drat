#' Decrypt and show solution
#'
#' @param key A key to decrypt file
#' @param show Whether to show decrypted document.
#' @importFrom utils menu
#' @importFrom safer decrypt_string
#' @importFrom rmarkdown render
#' @importFrom rstudioapi viewer
#' @importFrom xaringan moon_reader
#' @export
#' @examples
#' unveil(key = "123456")
unveil <- function(key, show = interactive()){
  rmd_files <- list.files(system.file(package = "solutions", "Rmd"), full.names = TRUE)
  if (show){
    which_rmd <- utils::menu(choices = basename(rmd_files), graphics = FALSE)
  } else {
    return(invisible(NULL))
  }

  if (which_rmd == 0L) return(invisible(NULL))

  input <- paste(readLines(rmd_files[which_rmd], warn = FALSE), collapse = "\n")
  decrypted <- safer::decrypt_string(input, key = key)
  file <- tempfile(fileext = ".Rmd")
  cat(decrypted, file = file)

  css_files <- list.files(system.file(package = "solutions", "css"), full.names = TRUE)
  css_dir_tmp <- file.path(tempdir(), "css")
  if (!dir.exists(css_dir_tmp)) dir.create(css_dir_tmp)
  for (f in css_files) file.copy(from = f, to = file.path(css_dir_tmp, basename(f)))

  html_file <- rmarkdown::render(file, 'rmarkdown::html_document')
  if (isTRUE(show)) rstudioapi::viewer(url = html_file)
  return(invisible(NULL))
}

