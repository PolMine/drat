* preparation workflow of the bt1819 corpus can be found here: https://gitlab.sowi.uni-due.de/christoph.leonhardt/plprbt19/blob/master/00_plpr_tei_to_cwb_MIDEM_Update.Rmd
