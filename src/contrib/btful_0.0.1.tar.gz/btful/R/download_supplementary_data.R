#' Download and load supplementary data from web directory.
#' 
#' \code{btful_download_lda_model} will download a lda topic model
#' from a directory (web dir) and store it in the btful package.
#' \code{btful_download_global_vectors} will download a global vectors model
#' from a directory (web dir) and store it in the btful package.
#' @param model Name of the model.
#' @param file Name of the global vectors file.
#' @param rds_file Name of the data file.
#' @param webdir (web) directory where the data file resides
#' @export btful_download_lda_model
#' @export btful_download_global_vectors

#' @rdname supplementary_data


btful_download_lda_model <- function(model = NULL,
                                     webdir = "https://polmine.sowi.uni-due.de/corpora/cwb/bundestag_1819/supplementary_data/topicmodels",
                                     user = NULL,
                                     password = NULL) {

  rds_file <- model

  
  if (is.null(user)) {
    if (Sys.getenv("RSTUDIO") == "1") user <- rstudioapi::showPrompt("Name", "Please enter your user name") else user <- readline(prompt = "Please enter your user name: ")   
  }
  if (is.null(password)) {
    if (Sys.getenv("RSTUDIO") == "1") password <- rstudioapi::askForPassword() else password <- readline(prompt = "Please enter password: ")
  }
  
  if (length(model) == 1) {
    tarball <- file.path(webdir, rds_file)
    message("... downloading supplementary data: ", basename(tarball))
    prefix <- gsub("^(https://|http://).*?$", 
                   "\\1", tarball)
    tarball <- gsub("^(https://|http://)(.*?)$", 
                    "\\2", tarball)
    download.file(url = sprintf("%s%s:%s@%s", 
                                prefix, user, password, tarball), destfile = paste0(file.path(system.file(package = "btful", "extdata", "supplementary_data", "topicmodels")), "/", 
                                                                                    rds_file))
  } else {
    for (x in model) btful_download_lda_model(model = x, webdir = webdir, user = user, password = password)
  }
}

btful_download_global_vectors <- function(file = NULL,
                                     webdir = "https://polmine.sowi.uni-due.de/corpora/cwb/bundestag_1819/supplementary_data/global_vectors",
                                     user = NULL,
                                     password = NULL) {

  rds_file <- file

  
  if (is.null(user)) {
    user <- readline(prompt = "Please enter your user name: ")
  }
  if (is.null(password)) {
    password <- readline(prompt = "Please enter password: ")
  }
  
  if (length(file) == 1) {
    tarball <- file.path(webdir, rds_file)
    message("... downloading supplementary data: ", basename(tarball))
    prefix <- gsub("^(https://|http://).*?$", 
                   "\\1", tarball)
    tarball <- gsub("^(https://|http://)(.*?)$", 
                    "\\2", tarball)
    download.file(url = sprintf("%s%s:%s@%s", 
                                prefix, user, password, tarball), destfile = paste0(file.path(system.file(package = "btful", "extdata", "supplementary_data", "global_vectors")), "/", 
                                                                                    rds_file))
  } else {
    for (x in file) btful_download_global_vectors(file = x, webdir = webdir, user = user, password = password)
  }
}