#' Download btful corpus from web directory.
#' 
#' \code{btful_download_corpus} will get a tarball with the indexed corpus
#' from a directory (web dir) and install the corpus into the btful package.
#' @param tarball Name of the tarball.
#' @param webdir (web) directory where the tarball resides.
#' @param archive logical; whether an older version of the corpus from the archive should be installed instead.
#' @param version if archive == TRUE, a corpus version must be specified.

#' @export btful_download_corpus
#' @rdname install_btful
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists

btful_download_corpus <- function(corpus = "btful", webdir = "http://polmine.sowi.uni-due.de/corpora/cwb/bundestag_1819", user = NULL, password = NULL, archive = FALSE, version = NULL) {
  
  if (archive == FALSE) {
    
    tarball <- file.path(webdir, sprintf("%s.tar.gz", tolower(corpus)))
    
  } else {
    
    webdir <- "https://polmine.sowi.uni-due.de/corpora/cwb/bundestag_1819/archive"
    
    if (is.null(version)) stop("... if archive is TRUE, then corpus version must be specified!")
    tarball <- file.path(webdir, sprintf("%s_%s.tar.gz", tolower(corpus), version))
    
  }
  
  
  if (is.null(user)){
    if (Sys.getenv("RSTUDIO") == "1") user <- rstudioapi::showPrompt("Name", "Please enter your user name") else user <- readline(prompt = "Please enter your user name: ")   
  }
  if (is.null(password)){
    if (Sys.getenv("RSTUDIO") == "1") password <- rstudioapi::askForPassword() else password <- readline(prompt = "Please enter password: ")
  }
  
  message("... downloading tarball: ", tarball)
  cwbtools::corpus_install(pkg = "btful", tarball = tarball, user = user, password = password)
  
  
}