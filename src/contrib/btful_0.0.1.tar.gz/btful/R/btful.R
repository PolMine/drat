#' Download BTFUL from Web Directory.
#' 
#' \code{btful_download_corpus} will get a tarball with the indexed corpus
#' from a designated web space or a local directory and install the corpus into
#' the btful package.
#' @param tarball Name of the tarball.
#' @param dir directory where the tarball resides, either the URL of a webspace,
#'   or a local directory
#' @export btful_download_corpus
#' @rdname btful
#' @name btful
#' @aliases btful_download_corpus btful BTFUL
#' @importFrom cwbtools corpus_install
#' @importFrom RCurl url.exists
