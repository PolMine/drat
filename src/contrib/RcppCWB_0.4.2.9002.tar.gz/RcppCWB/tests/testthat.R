library(testthat)
library(RcppCWB)

test_check("RcppCWB")
